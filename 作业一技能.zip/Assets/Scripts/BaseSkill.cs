using UnityEngine;

namespace SkillSystem
{
    public abstract class BaseSkill : ISkill
    {
        public string SkillName { get; protected set; }
        public float Cooldown { get; protected set; }
        public float ManaCost { get; protected set; }
        public float CurrentCooldown { get; set; }
        public ISkillCondition[] Conditions { get; set; }
        public ISkillEffect[] Effects { get; set; }

        protected BaseSkill(string skillName, float cooldown, float manaCost)
        {
            SkillName = skillName;
            Cooldown = cooldown;
            ManaCost = manaCost;
            CurrentCooldown = 0f;
            Conditions = new ISkillCondition[0];
            Effects = new ISkillEffect[0];
        }

        public virtual bool CanExecute(Player player)
        {
            if (CurrentCooldown > 0f)
            {
                return false;
            }

            foreach (var condition in Conditions)
            {
                if (!condition.Check(player))
                {
                    return false;
                }
            }

            return true;
        }

        public virtual void Execute(Player player)
        {
            if (!CanExecute(player))
            {
                return;
            }

            foreach (var condition in Conditions)
            {
                condition.Consume(player);
            }

            foreach (var effect in Effects)
            {
                effect.Apply(player);
            }

            CurrentCooldown = Cooldown;
        }

        public virtual void UpdateCooldown(float deltaTime)
        {
            if (CurrentCooldown > 0f)
            {
                CurrentCooldown = Mathf.Max(0f, CurrentCooldown - deltaTime);
            }
        }

        public virtual void ResetCooldown()
        {
            CurrentCooldown = 0f;
        }
    }
}
