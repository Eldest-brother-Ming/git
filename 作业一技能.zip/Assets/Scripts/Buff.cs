namespace SkillSystem
{
    public class Buff
    {
        public string Name { get; private set; }
        public float Amount { get; private set; }
        public float Duration { get; private set; }
        public bool IsExpired { get; private set; }

        public Buff(string name, float amount, float duration)
        {
            Name = name;
            Amount = amount;
            Duration = duration;
            IsExpired = false;
        }

        public void Update(float deltaTime)
        {
            Duration -= deltaTime;
            if (Duration <= 0f)
            {
                IsExpired = true;
            }
        }

        public void Reset(float newDuration)
        {
            Duration = newDuration;
            IsExpired = false;
        }
    }
}
