using UnityEngine;

namespace SkillSystem
{
    public class BuffEffect : ISkillEffect
    {
        private readonly string buffName;
        private readonly float buffAmount;
        private readonly float duration;

        public BuffEffect(string buffName, float buffAmount, float duration)
        {
            this.buffName = buffName;
            this.buffAmount = buffAmount;
            this.duration = duration;
        }

        public void Apply(Player player)
        {
            player.ApplyBuff(buffName, buffAmount, duration);
            Debug.Log($"获得 {buffName} 增益，持续 {duration} 秒");
        }

        public string GetEffectDescription()
        {
            return $"获得 {buffName} 增益，持续 {duration} 秒";
        }
    }
}
