using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

namespace SkillSystem
{
    public class CharacterSelectionController : MonoBehaviour
    {
        [SerializeField] private Button warriorButton;
        [SerializeField] private Button mageButton;
        [SerializeField] private Button priestButton;

        private void Start()
        {
            if (warriorButton != null)
            {
                warriorButton.onClick.AddListener(() => SelectCharacter(CharacterType.Warrior));
            }

            if (mageButton != null)
            {
                mageButton.onClick.AddListener(() => SelectCharacter(CharacterType.Mage));
            }

            if (priestButton != null)
            {
                priestButton.onClick.AddListener(() => SelectCharacter(CharacterType.Priest));
            }
        }

        private void SelectCharacter(string characterType)
        {
            PlayerPrefs.SetString("SelectedCharacter", characterType);
            PlayerPrefs.Save();
            Debug.Log($"选择了角色: {characterType}");
            SceneManager.LoadScene("SkillDemoScene");
        }
    }
}
