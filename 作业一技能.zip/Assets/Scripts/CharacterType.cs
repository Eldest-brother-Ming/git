namespace SkillSystem
{
    public class CharacterType
    {
        public const string Warrior = "Warrior";
        public const string Mage = "Mage";
        public const string Priest = "Priest";
    }
}
