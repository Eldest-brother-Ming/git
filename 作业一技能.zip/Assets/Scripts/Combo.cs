namespace SkillSystem
{
    public class Combo
    {
        public string ComboName { get; set; }
        public System.Collections.Generic.List<string> SkillSequence { get; set; }
        public float TimeWindow { get; set; }
        public ISkillEffect BonusEffect { get; set; }

        public Combo(string comboName, System.Collections.Generic.List<string> skillSequence, float timeWindow, ISkillEffect bonusEffect)
        {
            ComboName = comboName;
            SkillSequence = skillSequence;
            TimeWindow = timeWindow;
            BonusEffect = bonusEffect;
        }
    }
}
