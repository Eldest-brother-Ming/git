using System.Collections.Generic;
using UnityEngine;

namespace SkillSystem
{
    public class ComboSystem : MonoBehaviour
    {
        private List<string> recentSkills = new List<string>();
        private List<float> skillTimestamps = new List<float>();
        private List<Combo> availableCombos = new List<Combo>();
        private SkillManager skillManager;
        private Player player;

        public void Initialize(SkillManager skillManager, Player player)
        {
            this.skillManager = skillManager;
            this.player = player;
            InitializeDefaultCombos();
        }

        private void InitializeDefaultCombos()
        {
            availableCombos.Add(new Combo(
                "火盾连招",
                new List<string> { "火球术", "护盾" },
                3f,
                new BuffEffect("火焰护盾", 20f, 10f)
            ));

            availableCombos.Add(new Combo(
                "治疗连招",
                new List<string> { "治疗术", "治疗术" },
                2f,
                new HealEffect(30f)
            ));

            availableCombos.Add(new Combo(
                "召唤连招",
                new List<string> { "护盾", "召唤" },
                4f,
                new BuffEffect("召唤强化", 1.5f, 15f)
            ));
        }

        public void OnSkillUsed(string skillName)
        {
            recentSkills.Add(skillName);
            skillTimestamps.Add(Time.time);

            CleanupOldSkills();
            CheckForCombos();
        }

        private void CleanupOldSkills()
        {
            float currentTime = Time.time;
            for (int i = skillTimestamps.Count - 1; i >= 0; i--)
            {
                if (currentTime - skillTimestamps[i] > 5f)
                {
                    recentSkills.RemoveAt(i);
                    skillTimestamps.RemoveAt(i);
                }
            }
        }

        private void CheckForCombos()
        {
            foreach (var combo in availableCombos)
            {
                if (IsComboTriggered(combo))
                {
                    TriggerCombo(combo);
                    break;
                }
            }
        }

        private bool IsComboTriggered(Combo combo)
        {
            if (recentSkills.Count < combo.SkillSequence.Count)
            {
                return false;
            }

            int startIndex = recentSkills.Count - combo.SkillSequence.Count;
            float lastSkillTime = skillTimestamps[skillTimestamps.Count - 1];
            float firstSkillTime = skillTimestamps[startIndex];

            if (lastSkillTime - firstSkillTime > combo.TimeWindow)
            {
                return false;
            }

            for (int i = 0; i < combo.SkillSequence.Count; i++)
            {
                if (recentSkills[startIndex + i] != combo.SkillSequence[i])
                {
                    return false;
                }
            }

            return true;
        }

        private void TriggerCombo(Combo combo)
        {
            Debug.Log($"触发连招: {combo.ComboName}!");
            combo.BonusEffect.Apply(player);
            recentSkills.Clear();
            skillTimestamps.Clear();
        }

        public void AddCombo(Combo combo)
        {
            availableCombos.Add(combo);
        }

        public void RemoveCombo(string comboName)
        {
            availableCombos.RemoveAll(c => c.ComboName == comboName);
        }
    }
}
