namespace SkillSystem
{
    public class CooldownCondition : ISkillCondition
    {
        private readonly ISkill skill;

        public CooldownCondition(ISkill skill)
        {
            this.skill = skill;
        }

        public bool Check(Player player)
        {
            return skill.CurrentCooldown <= 0f;
        }

        public void Consume(Player player)
        {
        }

        public string GetFailureMessage()
        {
            return $"技能冷却中：{skill.CurrentCooldown:F1}秒";
        }
    }
}
