using UnityEngine;

namespace SkillSystem
{
    public class DamageEffect : ISkillEffect
    {
        private readonly float damage;

        public DamageEffect(float damage)
        {
            this.damage = damage;
        }

        public void Apply(Player player)
        {
            Debug.Log($"造成 {damage} 点伤害");
        }

        public string GetEffectDescription()
        {
            return $"造成 {damage} 点伤害";
        }
    }
}
