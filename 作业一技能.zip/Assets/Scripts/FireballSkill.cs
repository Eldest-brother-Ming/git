using UnityEngine;

namespace SkillSystem
{
    public class FireballSkill : BaseSkill
    {
        private readonly float damage;

        public FireballSkill(float cooldown, float manaCost, float damage) 
            : base("火球术", cooldown, manaCost)
        {
            this.damage = damage;
            Conditions = new ISkillCondition[]
            {
                new ManaCondition(manaCost),
                new CooldownCondition(this)
            };
            Effects = new ISkillEffect[]
            {
                new DamageEffect(damage)
            };
        }

        public override void Execute(Player player)
        {
            Debug.Log($"释放技能：{SkillName}");
            base.Execute(player);
        }
    }
}
