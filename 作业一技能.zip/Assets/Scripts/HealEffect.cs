using UnityEngine;

namespace SkillSystem
{
    public class HealEffect : ISkillEffect
    {
        private readonly float healAmount;

        public HealEffect(float healAmount)
        {
            this.healAmount = healAmount;
        }

        public void Apply(Player player)
        {
            player.Heal(healAmount);
            Debug.Log($"恢复 {healAmount} 点生命值");
        }

        public string GetEffectDescription()
        {
            return $"恢复 {healAmount} 点生命值";
        }
    }
}
