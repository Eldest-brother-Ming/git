using UnityEngine;

namespace SkillSystem
{
    public class HealSkill : BaseSkill
    {
        private readonly float healAmount;

        public HealSkill(float cooldown, float manaCost, float healAmount) 
            : base("治疗术", cooldown, manaCost)
        {
            this.healAmount = healAmount;
            Conditions = new ISkillCondition[]
            {
                new ManaCondition(manaCost),
                new CooldownCondition(this)
            };
            Effects = new ISkillEffect[]
            {
                new HealEffect(healAmount)
            };
        }

        public override void Execute(Player player)
        {
            Debug.Log($"释放技能：{SkillName}");
            base.Execute(player);
        }
    }
}
