namespace SkillSystem
{
    public class HealthCondition : ISkillCondition
    {
        private readonly float minHealthPercentage;

        public HealthCondition(float minHealthPercentage)
        {
            this.minHealthPercentage = minHealthPercentage;
        }

        public bool Check(Player player)
        {
            float healthPercentage = (float)player.CurrentHealth / player.MaxHealth;
            return healthPercentage >= minHealthPercentage;
        }

        public void Consume(Player player)
        {
        }

        public string GetFailureMessage()
        {
            return $"生命值不足！需要至少 {minHealthPercentage * 100}% 生命值";
        }
    }
}
