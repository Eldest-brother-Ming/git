using UnityEngine;

namespace SkillSystem
{
    public interface ISkill
    {
        string SkillName { get; }
        float Cooldown { get; }
        float ManaCost { get; }
        float CurrentCooldown { get; set; }
        ISkillCondition[] Conditions { get; set; }
        ISkillEffect[] Effects { get; set; }

        bool CanExecute(Player player);
        void Execute(Player player);
        void UpdateCooldown(float deltaTime);
        void ResetCooldown();
    }
}
