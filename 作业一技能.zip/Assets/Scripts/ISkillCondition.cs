namespace SkillSystem
{
    public interface ISkillCondition
    {
        bool Check(Player player);
        void Consume(Player player);
        string GetFailureMessage();
    }
}
