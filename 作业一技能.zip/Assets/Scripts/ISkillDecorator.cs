namespace SkillSystem
{
    public interface ISkillDecorator : ISkill
    {
        ISkill GetDecoratedSkill();
    }
}
