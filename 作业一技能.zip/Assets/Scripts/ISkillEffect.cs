namespace SkillSystem
{
    public interface ISkillEffect
    {
        void Apply(Player player);
        string GetEffectDescription();
    }
}
