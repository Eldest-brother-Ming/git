namespace SkillSystem
{
    public class ManaCondition : ISkillCondition
    {
        private readonly float requiredMana;

        public ManaCondition(float requiredMana)
        {
            this.requiredMana = requiredMana;
        }

        public bool Check(Player player)
        {
            return player.CurrentMana >= requiredMana;
        }

        public void Consume(Player player)
        {
            player.ConsumeMana(requiredMana);
        }

        public string GetFailureMessage()
        {
            return $"法力不足！需要 {requiredMana} 点法力";
        }
    }
}
