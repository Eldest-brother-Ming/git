using UnityEngine;
using System.Collections.Generic;

namespace SkillSystem
{
    public class Player : MonoBehaviour
    {
        public int MaxHealth { get; private set; } = 100;
        public int CurrentHealth { get; private set; } = 100;
        public int MaxMana { get; private set; } = 100;
        public int CurrentMana { get; private set; } = 100;
        public float ManaRegenRate { get; set; } = 5f;

        private Dictionary<string, Buff> activeBuffs = new Dictionary<string, Buff>();

        public void TakeDamage(int damage)
        {
            CurrentHealth = Mathf.Max(0, CurrentHealth - damage);
            Debug.Log($"玩家受到 {damage} 点伤害，当前生命值: {CurrentHealth}/{MaxHealth}");
        }

        public void Heal(float healAmount)
        {
            CurrentHealth = Mathf.Min(MaxHealth, CurrentHealth + (int)healAmount);
            Debug.Log($"玩家恢复 {healAmount} 点生命值，当前生命值: {CurrentHealth}/{MaxHealth}");
        }

        public void ConsumeMana(float manaCost)
        {
            CurrentMana = Mathf.Max(0, CurrentMana - (int)manaCost);
            Debug.Log($"消耗 {manaCost} 点法力，当前法力值: {CurrentMana}/{MaxMana}");
        }

        public void RegenerateMana(float deltaTime)
        {
            if (CurrentMana < MaxMana)
            {
                CurrentMana = Mathf.Min(MaxMana, CurrentMana + (int)(ManaRegenRate * deltaTime));
            }
        }

        public void ApplyBuff(string buffName, float buffAmount, float duration)
        {
            if (activeBuffs.ContainsKey(buffName))
            {
                activeBuffs[buffName].Reset(duration);
            }
            else
            {
                activeBuffs[buffName] = new Buff(buffName, buffAmount, duration);
            }
        }

        public void UpdateBuffs(float deltaTime)
        {
            var expiredBuffs = new List<string>();

            foreach (var kvp in activeBuffs)
            {
                kvp.Value.Update(deltaTime);
                if (kvp.Value.IsExpired)
                {
                    expiredBuffs.Add(kvp.Key);
                }
            }

            foreach (var buffName in expiredBuffs)
            {
                activeBuffs.Remove(buffName);
                Debug.Log($"增益 {buffName} 已过期");
            }
        }

        public bool HasBuff(string buffName)
        {
            return activeBuffs.ContainsKey(buffName);
        }

        public float GetBuffValue(string buffName)
        {
            return activeBuffs.ContainsKey(buffName) ? activeBuffs[buffName].Amount : 0f;
        }

        private void Update()
        {
            RegenerateMana(Time.deltaTime);
            UpdateBuffs(Time.deltaTime);
        }
    }
}
