using UnityEngine;

namespace SkillSystem
{
    public class ShieldSkill : BaseSkill
    {
        private readonly float shieldAmount;
        private readonly float duration;

        public ShieldSkill(float cooldown, float manaCost, float shieldAmount, float duration) 
            : base("护盾", cooldown, manaCost)
        {
            this.shieldAmount = shieldAmount;
            this.duration = duration;
            Conditions = new ISkillCondition[]
            {
                new ManaCondition(manaCost),
                new CooldownCondition(this)
            };
            Effects = new ISkillEffect[]
            {
                new BuffEffect("护盾", shieldAmount, duration)
            };
        }

        public override void Execute(Player player)
        {
            Debug.Log($"释放技能：{SkillName}");
            base.Execute(player);
        }
    }
}
