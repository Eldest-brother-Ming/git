using UnityEngine;
using UnityEngine.UI;

namespace SkillSystem
{
    public class SkillButton : MonoBehaviour
    {
        [SerializeField] private Button button;
        [SerializeField] private Text skillNameText;
        [SerializeField] private Text cooldownText;
        [SerializeField] private Text manaCostText;
        [SerializeField] private Image cooldownImage;

        private ISkill skill;
        private SkillManager skillManager;

        public void Initialize(ISkill skill, SkillManager skillManager)
        {
            this.skill = skill;
            this.skillManager = skillManager;

            if (button == null) button = GetComponent<Button>();
            if (skillNameText == null) skillNameText = transform.Find("SkillNameText")?.GetComponent<Text>();
            if (cooldownText == null) cooldownText = transform.Find("CooldownText")?.GetComponent<Text>();
            if (manaCostText == null) manaCostText = transform.Find("ManaCostText")?.GetComponent<Text>();
            if (cooldownImage == null) cooldownImage = transform.Find("CooldownImage")?.GetComponent<Image>();

            if (button != null)
            {
                button.onClick.AddListener(OnButtonClick);
            }

            UpdateUI();
        }

        private void OnButtonClick()
        {
            if (skillManager != null)
            {
                skillManager.TryExecuteSkill(skill.SkillName);
            }
        }

        public void UpdateUI()
        {
            if (skillNameText != null)
            {
                skillNameText.text = skill.SkillName;
            }

            if (cooldownText != null)
            {
                cooldownText.text = skill.CurrentCooldown > 0f ? $"{skill.CurrentCooldown:F1}s" : "";
            }

            if (manaCostText != null)
            {
                manaCostText.text = $"{skill.ManaCost} MP";
            }

            if (cooldownImage != null)
            {
                cooldownImage.fillAmount = skill.CurrentCooldown / skill.Cooldown;
                cooldownImage.gameObject.SetActive(skill.CurrentCooldown > 0f);
            }

            if (button != null)
            {
                button.interactable = skill.CurrentCooldown <= 0f;
            }
        }
    }
}
