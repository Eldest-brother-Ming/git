namespace SkillSystem
{
    public class SkillCommand : ICommand
    {
        private readonly ISkill skill;
        private readonly Player player;

        public SkillCommand(ISkill skill, Player player)
        {
            this.skill = skill;
            this.player = player;
        }

        public void Execute()
        {
            skill.Execute(player);
        }

        public void Undo()
        {
        }
    }
}
