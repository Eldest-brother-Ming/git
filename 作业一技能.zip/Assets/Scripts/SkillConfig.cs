using UnityEngine;

namespace SkillSystem
{
    [CreateAssetMenu(fileName = "NewSkillConfig", menuName = "Skill System/Skill Config")]
    public class SkillConfig : ScriptableObject
    {
        [Header("基本信息")]
        public string skillName;
        public SkillType skillType;
        public float cooldown;
        public float manaCost;

        [Header("火球术设置")]
        public float damage;

        [Header("治疗术设置")]
        public float healAmount;

        [Header("护盾设置")]
        public float shieldAmount;
        public float buffDuration;

        [Header("召唤设置")]
        public string summonName;
        public float summonDuration;
    }
}
