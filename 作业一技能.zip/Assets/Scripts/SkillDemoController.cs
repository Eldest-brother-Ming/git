using UnityEngine;

namespace SkillSystem
{
    public class SkillDemoController : MonoBehaviour
    {
        [SerializeField] private Player player;
        [SerializeField] private SkillManager skillManager;
        [SerializeField] private SkillUIController uiController;

        [Header("技能配置")]
        [SerializeField] private SkillConfig fireballConfig;
        [SerializeField] private SkillConfig healConfig;
        [SerializeField] private SkillConfig shieldConfig;
        [SerializeField] private SkillConfig summonConfig;

        private void Start()
        {
            InitializeSystem();
            LoadCharacterSkills();
        }

        private void InitializeSystem()
        {
            if (player == null)
            {
                player = FindObjectOfType<Player>();
            }

            if (skillManager == null)
            {
                skillManager = FindObjectOfType<SkillManager>();
            }

            if (uiController == null)
            {
                uiController = FindObjectOfType<SkillUIController>();
            }

            skillManager.Initialize(player, uiController);
            uiController.Initialize(player, skillManager);
        }

        private void LoadCharacterSkills()
        {
            string selectedCharacter = PlayerPrefs.GetString("SelectedCharacter", CharacterType.Mage);
            Debug.Log($"加载角色技能: {selectedCharacter}");

            switch (selectedCharacter)
            {
                case CharacterType.Warrior:
                    LoadWarriorSkills();
                    break;
                case CharacterType.Mage:
                    LoadMageSkills();
                    break;
                case CharacterType.Priest:
                    LoadPriestSkills();
                    break;
                default:
                    LoadMageSkills();
                    break;
            }
        }

        private void LoadWarriorSkills()
        {
            if (shieldConfig != null)
            {
                ISkill shieldSkill = SkillFactory.CreateSkill(shieldConfig);
                skillManager.AddSkill(shieldSkill);
            }

            if (summonConfig != null)
            {
                ISkill summonSkill = SkillFactory.CreateSkill(summonConfig);
                skillManager.AddSkill(summonSkill);
            }
        }

        private void LoadMageSkills()
        {
            if (fireballConfig != null)
            {
                ISkill fireballSkill = SkillFactory.CreateSkill(fireballConfig);
                skillManager.AddSkill(fireballSkill);
            }

            if (shieldConfig != null)
            {
                ISkill shieldSkill = SkillFactory.CreateSkill(shieldConfig);
                skillManager.AddSkill(shieldSkill);
            }
        }

        private void LoadPriestSkills()
        {
            if (healConfig != null)
            {
                ISkill healSkill = SkillFactory.CreateSkill(healConfig);
                skillManager.AddSkill(healSkill);
            }

            if (shieldConfig != null)
            {
                ISkill shieldSkill = SkillFactory.CreateSkill(shieldConfig);
                skillManager.AddSkill(shieldSkill);
            }
        }
    }
}
