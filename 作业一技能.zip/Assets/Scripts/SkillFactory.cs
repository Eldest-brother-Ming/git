using UnityEngine;

namespace SkillSystem
{
    public class SkillFactory
    {
        public static ISkill CreateSkill(SkillConfig config)
        {
            switch (config.skillType)
            {
                case SkillType.Fireball:
                    return new FireballSkill(
                        config.cooldown,
                        config.manaCost,
                        config.damage
                    );

                case SkillType.Heal:
                    return new HealSkill(
                        config.cooldown,
                        config.manaCost,
                        config.healAmount
                    );

                case SkillType.Shield:
                    return new ShieldSkill(
                        config.cooldown,
                        config.manaCost,
                        config.shieldAmount,
                        config.buffDuration
                    );

                case SkillType.Summon:
                    return new SummonSkill(
                        config.cooldown,
                        config.manaCost,
                        config.summonName,
                        config.summonDuration
                    );

                default:
                    Debug.LogError($"未知的技能类型: {config.skillType}");
                    return null;
            }
        }
    }

    public enum SkillType
    {
        Fireball,
        Heal,
        Shield,
        Summon
    }
}
