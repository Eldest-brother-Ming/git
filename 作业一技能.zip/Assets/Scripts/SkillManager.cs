using UnityEngine;
using System.Collections.Generic;

namespace SkillSystem
{
    public class SkillManager : MonoBehaviour
    {
        private Player player;
        private Dictionary<string, ISkill> skills = new Dictionary<string, ISkill>();
        private SkillUIController uiController;

        public void Initialize(Player player, SkillUIController uiController)
        {
            this.player = player;
            this.uiController = uiController;
        }

        public void AddSkill(ISkill skill)
        {
            if (!skills.ContainsKey(skill.SkillName))
            {
                skills.Add(skill.SkillName, skill);
                uiController?.AddSkillButton(skill);
            }
        }

        public void RemoveSkill(string skillName)
        {
            if (skills.ContainsKey(skillName))
            {
                skills.Remove(skillName);
                uiController?.RemoveSkillButton(skillName);
            }
        }

        public bool TryExecuteSkill(string skillName)
        {
            if (!skills.ContainsKey(skillName))
            {
                Debug.LogWarning($"技能 {skillName} 不存在");
                return false;
            }

            var skill = skills[skillName];

            if (!skill.CanExecute(player))
            {
                foreach (var condition in skill.Conditions)
                {
                    if (!condition.Check(player))
                    {
                        uiController?.ShowMessage(condition.GetFailureMessage());
                        break;
                    }
                }
                return false;
            }

            var command = new SkillCommand(skill, player);
            command.Execute();
            uiController?.UpdateSkillUI(skillName);
            return true;
        }

        public ISkill GetSkill(string skillName)
        {
            return skills.ContainsKey(skillName) ? skills[skillName] : null;
        }

        public IEnumerable<ISkill> GetAllSkills()
        {
            return skills.Values;
        }

        private void Update()
        {
            foreach (var skill in skills.Values)
            {
                skill.UpdateCooldown(Time.deltaTime);
            }
        }
    }
}
