using UnityEngine;
using UnityEngine.UI;
using System.Collections.Generic;

namespace SkillSystem
{
    public class SkillUIController : MonoBehaviour
    {
        [SerializeField] private Transform skillPanel;
        [SerializeField] private GameObject skillButtonPrefab;
        [SerializeField] private Text messageText;
        [SerializeField] private Text healthText;
        [SerializeField] private Text manaText;
        [SerializeField] private float messageDisplayTime = 2f;

        private Dictionary<string, SkillButton> skillButtons = new Dictionary<string, SkillButton>();
        private Player player;
        private SkillManager skillManager;
        private float messageTimer;

        private void Update()
        {
            if (player != null)
            {
                healthText.text = $"生命值: {player.CurrentHealth}/{player.MaxHealth}";
                manaText.text = $"法力值: {player.CurrentMana}/{player.MaxMana}";
            }

            UpdateSkillButtons();

            if (messageTimer > 0f)
            {
                messageTimer -= Time.deltaTime;
                if (messageTimer <= 0f)
                {
                    messageText.gameObject.SetActive(false);
                }
            }
        }

        public void Initialize(Player player, SkillManager skillManager)
        {
            this.player = player;
            this.skillManager = skillManager;
        }

        public void AddSkillButton(ISkill skill)
        {
            if (skillButtonPrefab == null || skillPanel == null)
            {
                Debug.LogError("技能按钮预制体或面板未设置");
                return;
            }

            GameObject buttonObj = Instantiate(skillButtonPrefab, skillPanel);
            SkillButton skillButton = buttonObj.GetComponent<SkillButton>();
            
            if (skillButton == null)
            {
                skillButton = buttonObj.AddComponent<SkillButton>();
            }

            skillButton.Initialize(skill, skillManager);
            skillButtons.Add(skill.SkillName, skillButton);
        }

        public void RemoveSkillButton(string skillName)
        {
            if (skillButtons.ContainsKey(skillName))
            {
                Destroy(skillButtons[skillName].gameObject);
                skillButtons.Remove(skillName);
            }
        }

        public void UpdateSkillUI(string skillName)
        {
            if (skillButtons.ContainsKey(skillName))
            {
                skillButtons[skillName].UpdateUI();
            }
        }

        public void UpdateSkillButtons()
        {
            foreach (var button in skillButtons.Values)
            {
                button.UpdateUI();
            }
        }

        public void ShowMessage(string message)
        {
            if (messageText != null)
            {
                messageText.text = message;
                messageText.gameObject.SetActive(true);
                messageTimer = messageDisplayTime;
            }
        }
    }
}
