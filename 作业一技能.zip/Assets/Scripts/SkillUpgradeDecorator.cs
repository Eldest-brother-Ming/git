namespace SkillSystem
{
    public class SkillUpgradeDecorator : ISkillDecorator
    {
        private readonly ISkill decoratedSkill;
        private readonly float damageMultiplier;
        private readonly float cooldownReduction;
        private readonly float manaCostReduction;

        public string SkillName => decoratedSkill.SkillName + " (升级)";
        public float Cooldown => decoratedSkill.Cooldown * cooldownReduction;
        public float ManaCost => decoratedSkill.ManaCost * manaCostReduction;
        public float CurrentCooldown 
        { 
            get => decoratedSkill.CurrentCooldown; 
            set => decoratedSkill.CurrentCooldown = value; 
        }
        public ISkillCondition[] Conditions 
        { 
            get => decoratedSkill.Conditions; 
            set => decoratedSkill.Conditions = value; 
        }
        public ISkillEffect[] Effects 
        { 
            get => decoratedSkill.Effects; 
            set => decoratedSkill.Effects = value; 
        }

        public ISkill GetDecoratedSkill()
        {
            return decoratedSkill;
        }

        public SkillUpgradeDecorator(ISkill skill, float damageMultiplier = 1.2f, float cooldownReduction = 0.9f, float manaCostReduction = 0.9f)
        {
            this.decoratedSkill = skill;
            this.damageMultiplier = damageMultiplier;
            this.cooldownReduction = cooldownReduction;
            this.manaCostReduction = manaCostReduction;
            UpgradeEffects();
        }

        private void UpgradeEffects()
        {
            var upgradedEffects = new ISkillEffect[decoratedSkill.Effects.Length];
            
            for (int i = 0; i < decoratedSkill.Effects.Length; i++)
            {
                if (decoratedSkill.Effects[i] is DamageEffect damageEffect)
                {
                    upgradedEffects[i] = CreateUpgradedDamageEffect(damageEffect);
                }
                else
                {
                    upgradedEffects[i] = decoratedSkill.Effects[i];
                }
            }
            
            Effects = upgradedEffects;
        }

        private DamageEffect CreateUpgradedDamageEffect(DamageEffect originalEffect)
        {
            var description = originalEffect.GetEffectDescription();
            if (string.IsNullOrEmpty(description))
            {
                return new DamageEffect(0);
            }

            var parts = description.Split(' ');
            if (parts.Length < 2)
            {
                return new DamageEffect(0);
            }

            if (float.TryParse(parts[1], out float originalDamage))
            {
                return new DamageEffect(originalDamage * damageMultiplier);
            }

            return new DamageEffect(0);
        }

        public bool CanExecute(Player player)
        {
            return decoratedSkill.CanExecute(player);
        }

        public void Execute(Player player)
        {
            decoratedSkill.Execute(player);
        }

        public void UpdateCooldown(float deltaTime)
        {
            decoratedSkill.UpdateCooldown(deltaTime);
        }

        public void ResetCooldown()
        {
            decoratedSkill.ResetCooldown();
        }
    }
}
