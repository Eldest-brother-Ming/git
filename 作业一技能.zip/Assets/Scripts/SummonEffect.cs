using UnityEngine;

namespace SkillSystem
{
    public class SummonEffect : ISkillEffect
    {
        private readonly string summonName;
        private readonly float duration;

        public SummonEffect(string summonName, float duration)
        {
            this.summonName = summonName;
            this.duration = duration;
        }

        public void Apply(Player player)
        {
            Debug.Log($"召唤 {summonName}，持续 {duration} 秒");
        }

        public string GetEffectDescription()
        {
            return $"召唤 {summonName}，持续 {duration} 秒";
        }
    }
}
