using UnityEngine;

namespace SkillSystem
{
    public class SummonSkill : BaseSkill
    {
        private readonly string summonName;
        private readonly float duration;

        public SummonSkill(float cooldown, float manaCost, string summonName, float duration) 
            : base("召唤", cooldown, manaCost)
        {
            this.summonName = summonName;
            this.duration = duration;
            Conditions = new ISkillCondition[]
            {
                new ManaCondition(manaCost),
                new CooldownCondition(this)
            };
            Effects = new ISkillEffect[]
            {
                new SummonEffect(summonName, duration)
            };
        }

        public override void Execute(Player player)
        {
            Debug.Log($"释放技能：{SkillName}");
            base.Execute(player);
        }
    }
}
