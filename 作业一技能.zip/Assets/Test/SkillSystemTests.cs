using NUnit.Framework;
using UnityEngine;
using SkillSystem;
using UnityEngine.TestTools;

namespace SkillSystem.Tests
{
    [TestFixture]
    public class SkillSystemTests
    {
        private Player player;

        [SetUp]
        public void SetUp()
        {
            var gameObject = new GameObject("TestPlayer");
            player = gameObject.AddComponent<Player>();
        }

        [TearDown]
        public void TearDown()
        {
            if (player != null)
            {
                Object.DestroyImmediate(player.gameObject);
            }
        }

        [Test]
        public void TestFireballSkill_ShouldHaveCorrectProperties()
        {
            var fireball = new FireballSkill(5f, 20f, 50f);

            Assert.AreEqual("火球术", fireball.SkillName, "技能名称应为'火球术'");
            Assert.AreEqual(5f, fireball.Cooldown, "冷却时间应为5秒");
            Assert.AreEqual(20f, fireball.ManaCost, "法力消耗应为20点");
            Assert.AreEqual(0f, fireball.CurrentCooldown, "初始冷却时间应为0");
        }

        [Test]
        public void TestFireballSkill_ShouldExecuteSuccessfully()
        {
            var fireball = new FireballSkill(5f, 20f, 50f);

            Assert.IsTrue(fireball.CanExecute(player), "应该可以执行火球术");
            fireball.Execute(player);
            Assert.AreEqual(5f, fireball.CurrentCooldown, "执行后冷却时间应为5秒");
            Assert.AreEqual(80, player.CurrentMana, "执行后法力值应为80");
        }

        [Test]
        public void TestFireballSkill_ShouldNotExecuteWhenOnCooldown()
        {
            var fireball = new FireballSkill(5f, 20f, 50f);
            fireball.Execute(player);

            Assert.IsFalse(fireball.CanExecute(player), "冷却中不应能执行");
            Assert.AreEqual(5f, fireball.CurrentCooldown, "冷却时间应为5秒");
        }

        [Test]
        public void TestFireballSkill_ShouldNotExecuteWhenInsufficientMana()
        {
            player.ConsumeMana(90f);
            var fireball = new FireballSkill(5f, 20f, 50f);

            Assert.IsFalse(fireball.CanExecute(player), "法力不足时不应能执行");
        }

        [Test]
        public void TestHealSkill_ShouldRestoreHealth()
        {
            player.TakeDamage(50);
            var heal = new HealSkill(3f, 15f, 30f);

            Assert.AreEqual(50, player.CurrentHealth, "受伤后生命值应为50");
            heal.Execute(player);
            Assert.AreEqual(80, player.CurrentHealth, "治疗后生命值应为80");
        }

        [Test]
        public void TestHealSkill_ShouldNotExceedMaxHealth()
        {
            var heal = new HealSkill(3f, 15f, 30f);

            Assert.AreEqual(100, player.CurrentHealth, "初始生命值应为100");
            heal.Execute(player);
            Assert.AreEqual(100, player.CurrentHealth, "治疗不应超过最大生命值");
        }

        [Test]
        public void TestShieldSkill_ShouldApplyBuff()
        {
            var shield = new ShieldSkill(10f, 30f, 20f, 5f);

            shield.Execute(player);
            Assert.IsTrue(player.HasBuff("护盾"), "应该有护盾增益");
            Assert.AreEqual(20f, player.GetBuffValue("护盾"), "护盾值应为20");
        }

        [Test]
        public void TestSummonSkill_ShouldLogSummon()
        {
            var summon = new SummonSkill(15f, 40f, "召唤狼", 30f);

            LogAssert.Expect(LogType.Log, new System.Text.RegularExpressions.Regex("召唤狼"));
            summon.Execute(player);
        }

        [Test]
        public void TestCooldownCondition_ShouldCheckCooldown()
        {
            var fireball = new FireballSkill(5f, 20f, 50f);
            var condition = new CooldownCondition(fireball);

            Assert.IsTrue(condition.Check(player), "初始状态应通过冷却检查");
            fireball.Execute(player);
            Assert.IsFalse(condition.Check(player), "冷却中不应通过检查");
        }

        [Test]
        public void TestManaCondition_ShouldCheckMana()
        {
            var condition = new ManaCondition(30f);

            Assert.IsTrue(condition.Check(player), "初始法力应足够");
            player.ConsumeMana(80f);
            Assert.IsFalse(condition.Check(player), "法力不足时应失败");
        }

        [Test]
        public void TestHealthCondition_ShouldCheckHealth()
        {
            var condition = new HealthCondition(0.5f);

            Assert.IsTrue(condition.Check(player), "初始生命值应足够");
            player.TakeDamage(60);
            Assert.IsFalse(condition.Check(player), "生命值不足时应失败");
        }

        [Test]
        public void TestDamageEffect_ShouldLogDamage()
        {
            var effect = new DamageEffect(50f);

            LogAssert.Expect(LogType.Log, new System.Text.RegularExpressions.Regex("50"));
            effect.Apply(player);
        }

        [Test]
        public void TestHealEffect_ShouldHealPlayer()
        {
            player.TakeDamage(50);
            var effect = new HealEffect(30f);

            effect.Apply(player);
            Assert.AreEqual(80, player.CurrentHealth, "效果应恢复30点生命值");
        }

        [Test]
        public void TestBuffEffect_ShouldApplyBuff()
        {
            var effect = new BuffEffect("测试增益", 10f, 5f);

            effect.Apply(player);
            Assert.IsTrue(player.HasBuff("测试增益"), "应该有测试增益");
            Assert.AreEqual(10f, player.GetBuffValue("测试增益"), "增益值应为10");
        }

        [Test]
        public void TestSummonEffect_ShouldLogSummon()
        {
            var effect = new SummonEffect("召唤狼", 30f);

            LogAssert.Expect(LogType.Log, new System.Text.RegularExpressions.Regex("召唤狼"));
            effect.Apply(player);
        }

        [Test]
        public void TestSkillUpgradeDecorator_ShouldIncreaseDamage()
        {
            var originalSkill = new FireballSkill(5f, 20f, 50f);
            var upgradedSkill = new SkillUpgradeDecorator(originalSkill, 1.5f, 1f, 1f);

            Assert.AreEqual("火球术 (升级)", upgradedSkill.SkillName, "升级后技能名称应包含'(升级)'");
            Assert.AreEqual(5f, upgradedSkill.Cooldown, "冷却时间应保持不变");
            Assert.AreEqual(20f, upgradedSkill.ManaCost, "法力消耗应保持不变");
        }

        [Test]
        public void TestSkillUpgradeDecorator_ShouldReduceCooldown()
        {
            var originalSkill = new FireballSkill(5f, 20f, 50f);
            var upgradedSkill = new SkillUpgradeDecorator(originalSkill, 1f, 0.8f, 1f);

            Assert.AreEqual(4f, upgradedSkill.Cooldown, "冷却时间应减少20%");
        }

        [Test]
        public void TestSkillUpgradeDecorator_ShouldReduceManaCost()
        {
            var originalSkill = new FireballSkill(5f, 20f, 50f);
            var upgradedSkill = new SkillUpgradeDecorator(originalSkill, 1f, 1f, 0.9f);

            Assert.AreEqual(18f, upgradedSkill.ManaCost, "法力消耗应减少10%");
        }

        [Test]
        public void TestSkillCommand_ShouldExecuteSkill()
        {
            var fireball = new FireballSkill(5f, 20f, 50f);
            var command = new SkillCommand(fireball, player);

            command.Execute();
            Assert.AreEqual(5f, fireball.CurrentCooldown, "命令执行后技能应进入冷却");
            Assert.AreEqual(80, player.CurrentMana, "命令执行后法力值应减少");
        }

        [Test]
        public void TestPlayer_ShouldTakeDamage()
        {
            player.TakeDamage(30);
            Assert.AreEqual(70, player.CurrentHealth, "受到30点伤害后生命值应为70");
        }

        [Test]
        public void TestPlayer_ShouldNotHaveNegativeHealth()
        {
            player.TakeDamage(150);
            Assert.AreEqual(0, player.CurrentHealth, "生命值不应为负数");
        }

        [Test]
        public void TestPlayer_ShouldRegenerateMana()
        {
            player.ConsumeMana(50f);
            Assert.AreEqual(50, player.CurrentMana, "消耗后法力值应为50");

            player.RegenerateMana(1f);
            Assert.Greater(player.CurrentMana, 50, "法力值应随时间恢复");
        }

        [Test]
        public void TestPlayer_ShouldNotExceedMaxMana()
        {
            player.RegenerateMana(10f);
            Assert.AreEqual(100, player.CurrentMana, "法力值不应超过最大值");
        }

        [Test]
        public void TestPlayer_ShouldApplyBuff()
        {
            player.ApplyBuff("测试增益", 10f, 5f);
            Assert.IsTrue(player.HasBuff("测试增益"), "应该有测试增益");
            Assert.AreEqual(10f, player.GetBuffValue("测试增益"), "增益值应为10");
        }

        [Test]
        public void TestPlayer_ShouldUpdateBuffDuration()
        {
            player.ApplyBuff("测试增益", 10f, 5f);
            player.UpdateBuffs(3f);

            Assert.IsTrue(player.HasBuff("测试增益"), "3秒后增益仍应存在");
            player.UpdateBuffs(3f);
            Assert.IsFalse(player.HasBuff("测试增益"), "6秒后增益应过期");
        }

        [Test]
        public void TestPlayer_ShouldResetBuffOnReapply()
        {
            player.ApplyBuff("测试增益", 10f, 5f);
            player.UpdateBuffs(3f);
            player.ApplyBuff("测试增益", 10f, 5f);

            Assert.IsTrue(player.HasBuff("测试增益"), "重新应用后增益应存在");
            player.UpdateBuffs(4f);
            Assert.IsTrue(player.HasBuff("测试增益"), "重置后增益应持续更长时间");
        }

        [Test]
        public void TestSkillFactory_ShouldCreateFireballSkill()
        {
            var config = ScriptableObject.CreateInstance<SkillConfig>();
            config.skillType = SkillType.Fireball;
            config.cooldown = 5f;
            config.manaCost = 20f;
            config.damage = 50f;

            var skill = SkillFactory.CreateSkill(config);

            Assert.IsNotNull(skill, "工厂应创建技能");
            Assert.IsInstanceOf<FireballSkill>(skill, "应创建火球术");
            Assert.AreEqual("火球术", skill.SkillName, "技能名称应为'火球术'");
        }

        [Test]
        public void TestSkillFactory_ShouldCreateHealSkill()
        {
            var config = ScriptableObject.CreateInstance<SkillConfig>();
            config.skillType = SkillType.Heal;
            config.cooldown = 3f;
            config.manaCost = 15f;
            config.healAmount = 30f;

            var skill = SkillFactory.CreateSkill(config);

            Assert.IsNotNull(skill, "工厂应创建技能");
            Assert.IsInstanceOf<HealSkill>(skill, "应创建治疗术");
            Assert.AreEqual("治疗术", skill.SkillName, "技能名称应为'治疗术'");
        }

        [Test]
        public void TestSkillFactory_ShouldCreateShieldSkill()
        {
            var config = ScriptableObject.CreateInstance<SkillConfig>();
            config.skillType = SkillType.Shield;
            config.cooldown = 10f;
            config.manaCost = 30f;
            config.shieldAmount = 20f;
            config.buffDuration = 5f;

            var skill = SkillFactory.CreateSkill(config);

            Assert.IsNotNull(skill, "工厂应创建技能");
            Assert.IsInstanceOf<ShieldSkill>(skill, "应创建护盾");
            Assert.AreEqual("护盾", skill.SkillName, "技能名称应为'护盾'");
        }

        [Test]
        public void TestSkillFactory_ShouldCreateSummonSkill()
        {
            var config = ScriptableObject.CreateInstance<SkillConfig>();
            config.skillType = SkillType.Summon;
            config.cooldown = 15f;
            config.manaCost = 40f;
            config.summonName = "召唤狼";
            config.summonDuration = 30f;

            var skill = SkillFactory.CreateSkill(config);

            Assert.IsNotNull(skill, "工厂应创建技能");
            Assert.IsInstanceOf<SummonSkill>(skill, "应创建召唤");
            Assert.AreEqual("召唤", skill.SkillName, "技能名称应为'召唤'");
        }

        [Test]
        public void TestSkillFactory_ShouldReturnNullForUnknownType()
        {
            var config = ScriptableObject.CreateInstance<SkillConfig>();
            config.skillType = (SkillType)999;

            var skill = SkillFactory.CreateSkill(config);

            Assert.IsNull(skill, "未知类型应返回null");
        }

        [Test]
        public void TestCombo_ShouldHaveCorrectProperties()
        {
            var combo = new Combo(
                "测试连招",
                new System.Collections.Generic.List<string> { "火球术", "治疗术" },
                3f,
                new DamageEffect(100f)
            );

            Assert.AreEqual("测试连招", combo.ComboName, "连招名称应为'测试连招'");
            Assert.AreEqual(2, combo.SkillSequence.Count, "连招应包含2个技能");
            Assert.AreEqual(3f, combo.TimeWindow, "时间窗口应为3秒");
            Assert.IsNotNull(combo.BonusEffect, "连招应有奖励效果");
        }

        [Test]
        public void TestBuff_ShouldExpireAfterDuration()
        {
            var buff = new Buff("测试增益", 10f, 5f);

            Assert.IsFalse(buff.IsExpired, "初始状态不应过期");
            buff.Update(3f);
            Assert.IsFalse(buff.IsExpired, "3秒后不应过期");
            buff.Update(3f);
            Assert.IsTrue(buff.IsExpired, "6秒后应过期");
        }

        [Test]
        public void TestBuff_ShouldResetDuration()
        {
            var buff = new Buff("测试增益", 10f, 5f);
            buff.Update(3f);
            buff.Reset(5f);

            Assert.IsFalse(buff.IsExpired, "重置后不应过期");
            buff.Update(5f);
            Assert.IsTrue(buff.IsExpired, "5秒后应过期");
        }

        [Test]
        public void TestSkillUpdateCooldown_ShouldDecreaseCooldown()
        {
            var fireball = new FireballSkill(5f, 20f, 50f);
            fireball.Execute(player);

            Assert.AreEqual(5f, fireball.CurrentCooldown, "执行后冷却时间应为5秒");
            fireball.UpdateCooldown(2f);
            Assert.AreEqual(3f, fireball.CurrentCooldown, "2秒后冷却时间应为3秒");
            fireball.UpdateCooldown(3f);
            Assert.AreEqual(0f, fireball.CurrentCooldown, "5秒后冷却时间应为0");
        }

        [Test]
        public void TestSkillResetCooldown_ShouldResetToZero()
        {
            var fireball = new FireballSkill(5f, 20f, 50f);
            fireball.Execute(player);

            Assert.AreEqual(5f, fireball.CurrentCooldown, "执行后冷却时间应为5秒");
            fireball.ResetCooldown();
            Assert.AreEqual(0f, fireball.CurrentCooldown, "重置后冷却时间应为0");
        }

        [Test]
        public void TestCharacterType_ShouldHaveCorrectConstants()
        {
            Assert.AreEqual("Warrior", CharacterType.Warrior, "战士类型应为'Warrior'");
            Assert.AreEqual("Mage", CharacterType.Mage, "法师类型应为'Mage'");
            Assert.AreEqual("Priest", CharacterType.Priest, "牧师类型应为'Priest'");
        }
    }
}
