using System.Collections;
using System.Collections.Generic;
using PureMVC.Interfaces;
using PureMVC.Patterns;
using UnityEngine;

// 敌我碰撞命令
public class EnemyCollisionCommand : SimpleCommand
{
    public override void Execute(INotification notification)
    {
        var gameDataProxy = Facade.RetrieveProxy(GameDataProxy.NAME) as GameDataProxy;

        // 如果玩家有无敌状态，忽略伤害
        var playerData = Facade.RetrieveProxy(PlayerDataProxy.NAME) as PlayerDataProxy;
        if (playerData.HasPowerUp && playerData.ActivePowerUp == PowerUpType.Invincible)
            return;

        // 扣血
        gameDataProxy.gameData.PlayerHealth--;
        gameDataProxy.gameData.CurrentScore -= 200;

        // 更新UI
        SendNotification(NotificationConsts.UPDATE_HEALTH, gameDataProxy.gameData.PlayerHealth);
        SendNotification(NotificationConsts.UPDATE_SCORE, gameDataProxy.gameData.CurrentScore);

        // 检查游戏结束
        if (gameDataProxy.gameData.PlayerHealth <= 0)
        {
            SendNotification(NotificationConsts.GAME_OVER, false); // false表示失败
        }
        else
        {
            // 播放受伤效果
            SendNotification(NotificationConsts.PLAYER_DAMAGED, 1);
        }
    }
}

