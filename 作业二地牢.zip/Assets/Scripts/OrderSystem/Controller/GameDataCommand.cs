using System.Collections;
using System.Collections.Generic;
using PureMVC.Interfaces;
using PureMVC.Patterns;
using UnityEngine;

public class GameDataCommand : SimpleCommand
{
    public override void Execute(INotification notification)
    {
        GameDataProxy gameDataProxy = Facade.RetrieveProxy(GameDataProxy.NAME) as GameDataProxy;
        if (notification.Name == NotificationConsts.CHANGE_GAMEDATA)
        {
            if (notification.Type == "GameState")
            {
                //切换游戏状态
                gameDataProxy.ChangeGameState((GameState)notification.Body);
            }
            if (notification.Type == "Level")
            {
                LevelData level = (LevelData)notification.Body;
                gameDataProxy.ChangeLevel(level);
            }
            if (notification.Type == "SwitchLevel")
            {
                //切换关卡
                gameDataProxy.SwitchLevel();
            }
            if(notification.Type == "SubTimer")
            {
                //每秒减少时间
                if (gameDataProxy.gameData.GameState == GameState.Playing)
                {
                    gameDataProxy.gameData.RemainingTime -= 1f;
                    if (gameDataProxy.gameData.RemainingTime <= 0)
                    {
                        gameDataProxy.gameData.RemainingTime = 0;
                        //时间耗尽，游戏结束
                        SendNotification(NotificationConsts.GAME_OVER,false);
                    }
                    else
                    {
                        //刷新UI
                        SendNotification(NotificationConsts.UPDATE_TIME,gameDataProxy.gameData.RemainingTime);
                    }
                }
            }
        }

    }
}
