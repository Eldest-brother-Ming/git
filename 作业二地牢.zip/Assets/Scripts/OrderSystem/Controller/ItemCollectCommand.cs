using System.Collections;
using System.Collections.Generic;
using PureMVC.Interfaces;
using PureMVC.Patterns;
using UnityEngine;

// 物品收集命令
public class ItemCollectCommand : SimpleCommand
{
    public override void Execute(INotification notification)
    {
        var item = notification.Body as GameObject;
        var gameDataProxy = Facade.RetrieveProxy(GameDataProxy.NAME) as GameDataProxy;
        var levelDataProxy = Facade.RetrieveProxy(LevelDataProxy.NAME) as LevelDataProxy;
        // 更新收集数量
        gameDataProxy.gameData.CollectedItems++;
        gameDataProxy.gameData.CurrentScore += 100;

        // 销毁物品
        GameObject.Destroy(item);

        // 检查关卡完成条件
        if (gameDataProxy.gameData.CollectedItems >= gameDataProxy.gameData.TotalItems)
        {
            if (gameDataProxy.gameData.CurrentLevel >= levelDataProxy.levels.Count)
            {
                Debug.Log("所有关卡已完成");
                // 更新UI
                SendNotification(NotificationConsts.UPDATE_SCORE, gameDataProxy.gameData.CurrentScore);
                SendNotification(NotificationConsts.ITEM_COLLECTED_UI, gameDataProxy.gameData.CollectedItems);
                SendNotification(NotificationConsts.CHANGE_GAMEDATA,GameState.GameOver,"GameState");
                SendNotification(NotificationConsts.GAME_OVER,true);
                return;
            }
            Debug.Log("关卡已完成，开启下一关");
            //发送命令切换到下一关
            SendNotification(NotificationConsts.LOAD_LEVEL, null, "NextLevel");
        }

        // 更新UI
        SendNotification(NotificationConsts.UPDATE_SCORE, gameDataProxy.gameData.CurrentScore);
        SendNotification(NotificationConsts.ITEM_COLLECTED_UI, gameDataProxy.gameData.CollectedItems);
    }
}