using System.Collections;
using System.Collections.Generic;
using PureMVC.Interfaces;
using PureMVC.Patterns;
using UnityEngine;

public class LoadLevelCommand : SimpleCommand
{
    public override void Execute(INotification notification)
    {
        GameDataProxy gameDataProxy = Facade.RetrieveProxy(GameDataProxy.NAME) as GameDataProxy;
        EnemySpawnerProxy enemySpawnerProxy = Facade.RetrieveProxy(EnemySpawnerProxy.NAME) as EnemySpawnerProxy;
        ItemProxy itemProxy = Facade.RetrieveProxy(ItemProxy.NAME) as ItemProxy;
        PlayerDataProxy playerDataProxy = Facade.RetrieveProxy(PlayerDataProxy.NAME) as PlayerDataProxy;
        ObstacleProxy obstacleProxy = Facade.RetrieveProxy(ObstacleProxy.NAME) as ObstacleProxy;
        //切换下一关逻辑
        if (notification.Type == "NextLevel")
        {
            //1、切换关卡数据
            gameDataProxy.SwitchLevel();
            //2、重新加载地图
            MapMgr.instance.ParseMap(GameModel.Instance.currentLevelData);
            //3、重新生成敌人数据
            enemySpawnerProxy.CreateEnemy();
            //4、重新生成物品数据
            itemProxy.CreateItem();
            //5、重新生成障碍物数据
            obstacleProxy.CreateItem();
            //6、重置玩家位置
            playerDataProxy.PlayerPosition = Vector2.zero;

            //发通知重新生成敌人、物品和障碍物
            SendNotification(NotificationConsts.LEVEL_STARTED);
            //刷新UI
            SendNotification(NotificationConsts.ReFRESH_GAME_UI);
        }
        //返回选关
        if (notification.Type == "ReturnSelectLevel")
        {
            //清空关卡数据
            MapMgr.instance.ClearMap();
            enemySpawnerProxy.ClearEnemyData();
            itemProxy.ClearItemData();
            obstacleProxy.ClearItemData();

            //改变状态为选关
            SendNotification(NotificationConsts.CHANGE_GAMEDATA, GameState.MainMenu, "GameState");
            //发消息通知UI切换
            SendNotification(NotificationConsts.GAME_EXIT);
        }
        if (notification.Type == "StartLevel")
        {
            enemySpawnerProxy.CreateEnemy();
            itemProxy.CreateItem();
            obstacleProxy.CreateItem();
            playerDataProxy.PlayerPosition = Vector2.zero;
            playerDataProxy.InitPlayerData();
            SendNotification(NotificationConsts.ReFRESH_GAME_UI);
        }
    }
}
