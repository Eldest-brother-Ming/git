using System.Collections;
using System.Collections.Generic;
using PureMVC.Interfaces;
using PureMVC.Patterns;
using UnityEngine;

// 暂停游戏命令
public class PauseGameCommand : SimpleCommand
{
    public override void Execute(INotification notification)
    {
        var gameDataProxy = Facade.RetrieveProxy(GameDataProxy.NAME) as GameDataProxy;
        
        if (gameDataProxy.gameData.GameState == GameState.Playing)
        {
            gameDataProxy.gameData.GameState = GameState.Paused;
            Debug.Log("当前状态为：" + gameDataProxy.gameData.GameState);
            Time.timeScale = 0;
            SendNotification(NotificationConsts.GAME_PAUSED);
        }
        else if (gameDataProxy.gameData.GameState == GameState.Paused)
        {
            gameDataProxy.gameData.GameState = GameState.Playing;
            Debug.Log("当前状态为：" + gameDataProxy.gameData.GameState);
            Time.timeScale = 1;
            SendNotification(NotificationConsts.GAME_RESUMED);
        }
    }
}
