using System;
using System.Collections;
using System.Collections.Generic;
using PureMVC.Interfaces;
using PureMVC.Patterns;
using UnityEngine;
using UnityEngine.UIElements;

// 玩家移动命令
public class PlayerMoveCommand : SimpleCommand
{
    public override void Execute(INotification notification)
    {
        var input = (Vector2)notification.Body;
        var playerDataProxy = Facade.RetrieveProxy(PlayerDataProxy.NAME) as PlayerDataProxy;
        var gameDataProxy = Facade.RetrieveProxy(GameDataProxy.NAME) as GameDataProxy;
        var levelDataProxy = Facade.RetrieveProxy(LevelDataProxy.NAME) as LevelDataProxy;

        // 游戏未开始,直接返回不处理
        if (gameDataProxy.gameData.GameState != GameState.Playing) return;

        //Debug.Log("输入:" + input);
        // 计算新位置
        Vector2 newPosition = playerDataProxy.PlayerPosition +
                             input * playerDataProxy.MoveSpeed * Time.deltaTime;

        // 边界检查
        LevelData levelData = levelDataProxy.levels[gameDataProxy.gameData.CurrentLevel-1];
        Vector2 mapSize = levelData.CurrentLevelConfig.MapSize;
        newPosition = ClampPosition(newPosition, mapSize);

        // 碰撞检查
        if (!CheckCollision(newPosition,levelData.ObstaclePositions))
        {
            //Debug.Log("移动位置:" + newPosition);
            playerDataProxy.PlayerPosition = newPosition;
            SendNotification(NotificationConsts.PLAYER_MOVE, newPosition);
        }
    }

    /// <summary>
    /// 检查碰撞
    /// </summary>
    /// <param name="newPosition"></param>
    private bool CheckCollision(Vector2 newPosition, List<Vector2> obstaclePositions)
    {
        foreach (var obstaclePos in obstaclePositions)
        {
            if (Vector2.Distance(newPosition, obstaclePos) <= 0.6f)
            {
                return true; // 碰撞
            }
        }
        return false;
    }

    /// <summary>
    /// 边界检查
    /// </summary>
    private Vector2 ClampPosition(Vector2 newPosition, Vector2 mapSize)
    {
        newPosition.x = Mathf.Clamp(newPosition.x, 0, mapSize.x-1);
        newPosition.y = Mathf.Clamp(newPosition.y, 0, mapSize.y-1);
        return newPosition;
    }
}
