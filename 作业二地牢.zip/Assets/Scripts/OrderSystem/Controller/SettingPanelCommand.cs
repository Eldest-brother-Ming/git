using System.Collections;
using System.Collections.Generic;
using PureMVC.Interfaces;
using PureMVC.Patterns;
using UnityEngine;

public class SettingPanelCommand : SimpleCommand
{
    public override void Execute(INotification notification)
    {
        SettingsProxy settingProxy = Facade.RetrieveProxy(SettingsProxy.NAME) as SettingsProxy;
        // 更新设置
        if (notification.Name == NotificationConsts.UPDATE_SETTINGS)
        {
            if (notification.Type == "Sound")
            {
                float volume = (float)notification.Body;
                settingProxy.SetSoundVolume(volume);
            }
            if (notification.Type == "Music")
            {
                float volume = (float)notification.Body;
                settingProxy.SetMusicVolume(volume);
            }
        }
    }
}
