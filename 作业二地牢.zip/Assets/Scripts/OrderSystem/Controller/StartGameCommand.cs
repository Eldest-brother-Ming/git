using System;
using System.Collections;
using System.Collections.Generic;
using PureMVC.Interfaces;
using PureMVC.Patterns;
using UnityEngine;

// 开始游戏命令
public class StartGameCommand : SimpleCommand
{
    public override void Execute(INotification notification)
    {
        var level = (int)notification.Body;
        var gameDataProxy = Facade.RetrieveProxy(GameDataProxy.NAME) as GameDataProxy;

        // 初始化游戏数据
        gameDataProxy.gameData.CurrentLevel = level;
        gameDataProxy.gameData.GameState = GameState.Playing;
        gameDataProxy.gameData.PlayerHealth = 3;
        gameDataProxy.gameData.CurrentScore = 0;
        gameDataProxy.gameData.RemainingTime = GetLevelTimeLimit(level);

        // 发送通知更新UI
        SendNotification(NotificationConsts.LOAD_LEVEL, level);
    }

    // 获取当前关卡的时间限制
    private float GetLevelTimeLimit(int level)
    {
        float timerlimit = 60f;

        return timerlimit;  
    }
}