﻿using System;
using PureMVC.Interfaces;
using PureMVC.Patterns;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace OrderSystem
{
    internal class StartUpCommand : SimpleCommand
    {
        public override void Execute(INotification notification)
        {
            if (notification.Type == "StartGame")
            {
                Facade.RegisterProxy(new LevelDataProxy());
                Facade.RegisterProxy(new GameDataProxy());
                Facade.RegisterProxy(new PlayerDataProxy());
                Facade.RegisterProxy(new MainMenuProxy());
                Facade.RegisterProxy(new SettingsProxy());

            }

            if (notification.Type == "MainMenu")
            {

                // 注册Command
                Facade.RegisterCommand(NotificationConsts.CHANGE_GAMEDATA, typeof(GameDataCommand));

                Facade.RegisterCommand(NotificationConsts.START_GAME, typeof(StartGameCommand));
                Facade.RegisterCommand(NotificationConsts.LOAD_LEVEL, typeof(LoadLevelCommand));
                Facade.RegisterCommand(NotificationConsts.PLAYER_MOVE_INPUT, typeof(PlayerMoveCommand));
                Facade.RegisterCommand(NotificationConsts.ITEM_COLLECTED, typeof(ItemCollectCommand));
                Facade.RegisterCommand(NotificationConsts.ENEMY_COLLISION, typeof(EnemyCollisionCommand));
                Facade.RegisterCommand(NotificationConsts.PAUSE_GAME, typeof(PauseGameCommand));
                Facade.RegisterCommand(NotificationConsts.SAVE_GAME, typeof(SaveGameCommand));
                Facade.RegisterCommand(NotificationConsts.UPDATE_SETTINGS, typeof(SettingPanelCommand));


                Facade.RegisterMediator(new MainMenuMediator(new MainMenuView()));
                Facade.RegisterMediator(new SettingMediator(new SettingView()));

                // 发送命令修改游戏状态为主菜单                                     
                SendNotification(NotificationConsts.CHANGE_GAMEDATA, GameState.MainMenu, "GameState");
            }

            if (notification.Type == "Playing")
            {
                // 注册游戏场景代理
                Facade.RegisterProxy(new EnemySpawnerProxy());
                Facade.RegisterProxy(new ItemProxy());
                Facade.RegisterProxy(new ObstacleProxy());



                // 注册游戏场景使用的Mediator
                Facade.RegisterMediator(new GameUIMediator(new GameUIView()));
                Facade.RegisterMediator(new PlayerMediator(new PlayerView()));
                Facade.RegisterMediator(new ItemMediator(new ItemView()));
                Facade.RegisterMediator(new EnemySpawnerMediator(new EnemySpawnerView()));
                Facade.RegisterMediator(new ItemMediator(new ItemView()));
                Facade.RegisterMediator(new ObstacleMediator(new ObstacleView()));

                //发送通知加载关卡数据
                SendNotification(NotificationConsts.LOAD_LEVEL, null, "StartLevel");
                SendNotification(NotificationConsts.LEVEL_STARTED, GameModel.Instance.currentLevelData.CurrentLevelConfig.LevelId);
            }



            // 初始化游戏，加载关卡1
            // SendNotification(NotificationConsts.LOAD_LEVEL, 1);


        }
    }
}