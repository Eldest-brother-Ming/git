﻿using UnityEngine;
using UnityEngine.SceneManagement;

namespace OrderSystem
{
    public class GameFacade : MonoBehaviour
    {
        private static GameFacade instance;
        public static GameFacade Instance { get => instance; set => instance = value; }

        public ApplicationFacade facade;
        public bool isPlaying = false;
        public bool isReStart = false;
        public GameObject Canvas;
        void Awake()
        {
            // 确保只有一个实例存在
            if (instance != null && instance != this)
            {
                Destroy(gameObject); // 销毁重复的实例
                return;
            }

            instance = this;
            DontDestroyOnLoad(gameObject);
            Canvas = Instantiate(Resources.Load<GameObject>("Prefabs/UI/Canvas"));
            Canvas.name = "Canvas";
            DontDestroyOnLoad(Canvas);
            //数据先行
            ConfigMgr.Instance.LoadLevelConfig();
            facade = new ApplicationFacade();

        }

        private void Start()
        {
            // 显示主菜单
            // AppFacade.Instance.SendNotification(NotificationConsts.STARTUP);

            // 在StartUp的命令初始化中显示主菜单
            facade.StartUp(this);
        }

        void Update()
        {
            if (SceneManager.GetActiveScene().name == "BattleScene" && isPlaying == false && isReStart == false)
            {
                isPlaying = true;
                facade.SendNotification(NotificationConsts.STARTUP, null, "Playing");
            }
            else if (SceneManager.GetActiveScene().name == "BattleScene" && isReStart == false)
            {
                //发送通知加载关卡数据
                isReStart = true;
                facade.SendNotification(NotificationConsts.LOAD_LEVEL, null, "StartLevel");
                facade.SendNotification(NotificationConsts.LEVEL_STARTED, GameModel.Instance.currentLevelData.CurrentLevelConfig.LevelId);
            }

            if (SceneManager.GetActiveScene().name != "BattleScene" && isPlaying == true)
            {
                isReStart = false;
            }
        }
    }
}
