using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameModel : Singleton<GameModel>
{
    public LevelData currentLevelData;
    public List<GameObject> grounds = new List<GameObject>(); //地板 
}
