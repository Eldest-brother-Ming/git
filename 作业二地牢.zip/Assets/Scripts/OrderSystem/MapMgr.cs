using System.Collections;
using System.Collections.Generic;
using PureMVC.Patterns;
using PureMVC.Interfaces;
using UnityEngine;
using System;
using Unity.AI.Navigation;

public class MapMgr : MonoBehaviour
{
    public static MapMgr instance;


    void Awake()
    {
        instance = this;
    }
    // Start is called before the first frame update
    void Start()
    {
        ParseMap(GameModel.Instance.currentLevelData);
    }

    /// <summary>
    /// 加载地图
    /// </summary>
    /// <param name="levelData"></param>
    public void ParseMap(LevelData levelData)
    {
        if (levelData == null) return;

        ClearMap();

        int x = (int)levelData.CurrentLevelConfig.MapSize.x;
        int y = (int)levelData.CurrentLevelConfig.MapSize.y;
        for (int i = 0; i < x; i++)
        {
            for (int j = 0; j < y; j++)
            {
                Vector2 pos = new Vector2(i, j);
                GameObject ground = GameObject.Instantiate(Resources.Load<GameObject>("Prefabs/Prefab/Ground"), this.transform);
                ground.transform.parent = this.transform;
                ground.transform.position = pos;
                GameModel.Instance.grounds.Add(ground);
            }
        }

    }

    internal void ClearMap()
    {
        if (GameModel.Instance.grounds.Count > 0)
        {

            foreach (var item in GameModel.Instance.grounds)
            {
                Destroy(item);
            }
            GameModel.Instance.grounds.Clear();
        }
    }
}
