using System;
using System.Collections;
using System.Collections.Generic;
using PureMVC.Patterns;
using UnityEngine;
public class ItemData
{
    public Vector2 itemPosition;
    public GameObject itemObj;
}
public class ItemProxy : Proxy
{
    public new const string NAME = "CollectProxy";

    public List<ItemData> ItemDatas
    {
        get
        {
            return (List<ItemData>)Data;
        }
    }
    public ItemProxy() : base(NAME, new List<ItemData>())
    {

    }
    public override void OnRegister()
    {
        //CreateItem();

    }

    //创建物品
    public void CreateItem()
    {
        
        ClearItemData();
        for (int i = 0; i < GameModel.Instance.currentLevelData.ItemPositions.Count; i++)
        {
            ItemDatas.Add(new ItemData
            {
                itemPosition = GameModel.Instance.currentLevelData.ItemPositions[i],
                itemObj = null
            });
        }
    }

    //销毁物品
    public void DestoryAllItem()
    {
        for (int i = 0; i < ItemDatas.Count; i++)
        {
            if (ItemDatas[i].itemObj != null)
                GameObject.Destroy(ItemDatas[i].itemObj);
        }
    }

    //添加物品信息
    public void AddItemData(ItemData itemData)
    {
        ItemDatas.Add(itemData);
    }
    public void RemoveItemData(ItemData itemData)
    {
        ItemDatas.Remove(itemData);
    }
    public void ClearItemData()
    {
        DestoryAllItem();
        ItemDatas.Clear();
    }
}
