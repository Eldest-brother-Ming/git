using System.Collections;
using System.Collections.Generic;
using Newtonsoft.Json;
using UnityEngine;

// 游戏状态枚举
public enum GameState
{
    None = 0,
    MainMenu,   // 主菜单
    Playing,    // 游戏进行中
    Paused,     // 游戏暂停
    GameOver,   // 游戏结束
    LevelComplete   // 关卡完成
}

// 道具类型枚举
public enum PowerUpType
{
    None = 0,   // 无道具
    SpeedBoost = 1, // 加速
    Invincible = 2, // 无敌
    DoubleScore = 3,    // 双倍积分
    Magnet = 4  // 磁力
}

public enum EnemyPattern
{
    Patrol = 1,
    Idel = 2,

}

// 关卡配置
[System.Serializable]
public class LevelConfig
{
    public int LevelId; // 关卡ID
    public string LevelName;    // 关卡名称
    public int ItemCount;   // 物品数量
    public int EnemyCount;  // 敌人数量
    public float TimeLimit; // 时间限制

    // 标记转换器：处理 [{"X":10,"Y":10}] 格式
    [JsonConverter(typeof(Vector2ArrayConverter))]
    public Vector2 MapSize; // 地图大小
    public string SceneName;    // 关卡场景名称

    // 敌人配置
    public float EnemySpeed;    // 敌人速度
    public EnemyPattern EnemyPattern;   // 敌人模式

    // 奖励条件
    public int PerfectTimeBonus;    // 完美通关奖励(无伤)
    public int NoDamageBonus;       // 无伤奖励
}

// 敌人数据
[System.Serializable]
public class EnemyData
{
    [JsonConverter(typeof(Vector2ArrayConverter))]
    public Vector2 Position;
    // 标记转换器：处理 [{"X":x,"Y":y}, ...] 格式
    [JsonConverter(typeof(Vector2ListConverter))]
    public List<Vector2> PatrolPoints { get; set; }
    public float Speed;
    //public EnemyType Type;

    [JsonIgnore] 
    public GameObject EnemyObject;
}

// 道具数据
[System.Serializable]
public class PowerUpData
{
    public PowerUpType Type;
    public float Duration;
    public int Value; // 数值效果（如加速百分比）
    public GameObject PropObject;
}
