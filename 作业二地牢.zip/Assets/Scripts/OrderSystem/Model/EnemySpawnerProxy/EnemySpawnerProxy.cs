using System;
using System.Collections;
using System.Collections.Generic;
using PureMVC.Patterns;
using UnityEngine;

public class EnemySpawnerProxy : Proxy
{
    public new const string NAME = "EnemySpawnerProxy";

    public List<EnemyData> Enemies
    {
        get
        {
            return (List<EnemyData>)Data;
        }
    }

    public EnemySpawnerProxy() : base(NAME, new List<EnemyData>())
    {
        
    }

    public override void OnRegister()
    {
        //CreateEnemy();

    }

    /// <summary>
    /// 创建敌人
    /// </summary>
    public void CreateEnemy()
    {
        ClearEnemyData();
        //加载当前关卡所有敌人数据
        for (int i = 0; i < GameModel.Instance.currentLevelData.Enemies.Count; i++)
        {
            Enemies.Add(GameModel.Instance.currentLevelData.Enemies[i]);
        }
        Debug.Log("当前关卡敌人数量：" + Enemies.Count);
    }

    //销毁所有敌人
    private void DestoryAllEnemy()
    {
        for (int i = 0; i < Enemies.Count; i++)
        {
            if (Enemies[i].EnemyObject != null)
                GameObject.Destroy(Enemies[i].EnemyObject);
        }
    }

    //添加敌人数据
    public void AddEnemyData(EnemyData enemyData)
    {
        Enemies.Add(enemyData);
    }

    //移除敌人数据
    public void RemoveEnemyData(EnemyData enemyData)
    {
        Enemies.Remove(enemyData);
    }
    //清空敌人数据
    public void ClearEnemyData()
    {
        DestoryAllEnemy();
        Enemies.Clear();
    }
}
