public class GameData
{
    // 玩家数据
    public int CurrentScore { get; set; }   // 当前分数
    public int PlayerHealth { get; set; }   // 玩家生命值
    public int CollectedItems { get; set; } // 已收集的道具数
    public int TotalItems { get; set; } // 总道具数
    public float RemainingTime { get; set; }    // 剩余时间


    // 游戏状态
    public GameState GameState { get; set; }    // 当前游戏状态
    public int CurrentLevel { get; set; }   // 当前关卡
}