using System.Collections;
using System.Collections.Generic;
using PureMVC.Patterns;
using UnityEngine;
using UnityEngine.SceneManagement;
/// <summary>
/// 游戏数据代理
/// </summary>
public class GameDataProxy : Proxy
{
    public new const string NAME = "GameDataProxy";

    public GameData gameData;


    //无参构造
    public GameDataProxy() : base(NAME, null)
    {
        gameData = new GameData();
    }

    //代理注册时调用初始化数据
    public override void OnRegister()
    {
        base.OnRegister();
        //初始化玩家数据
        gameData.PlayerHealth = 3;  // 玩家生命3
        gameData.GameState = GameState.MainMenu;
        ChangeLevel(ConfigMgr.Instance._allLevelDatas[0]);
    }

    public void ChangeGameState(GameState state)
    {
        gameData.GameState = state;
        Debug.Log("当前状态为：" + gameData.GameState);
        if (state == GameState.Playing)
        {
            SceneManager.LoadScene("BattleScene");
        }
        if (state == GameState.MainMenu)
        {
            if (SceneManager.GetActiveScene().name != "MainMenu")
            {
                SceneManager.LoadScene("MainMenu");
                //数据重置
                gameData.CollectedItems = 0;
                gameData.CurrentScore = 0;
            }
        }
    }



    public void ChangeLevel(LevelData data)
    {
        if (data.CurrentLevelConfig.LevelId > 3 || data.CurrentLevelConfig.LevelId < 1)
        {
            Debug.Log("无效关卡");
            return;
        }

        gameData.CurrentLevel = data.CurrentLevelConfig.LevelId;
        gameData.TotalItems = data.CurrentLevelConfig.ItemCount;
        gameData.PlayerHealth = 3;  // 每关开始时重置玩家生命
        gameData.CollectedItems = 0;
        gameData.CurrentScore = 0;
        gameData.RemainingTime = data.CurrentLevelConfig.TimeLimit;

        //发送通知更新主界面
        SendNotification(NotificationConsts.UPDATE_CURSELECTLEVEL, gameData.CurrentLevel);
        GameModel.Instance.currentLevelData = data;
    }

    //切换到下一关
    public void SwitchLevel()
    {
        int nextLevelId = gameData.CurrentLevel + 1;
        if (nextLevelId > 3)
        {
            nextLevelId = 3;
            Debug.Log("没有下一关了");
            //弹出结算界面

            return;
        }
        LevelData data = ConfigMgr.Instance._allLevelDatas[nextLevelId - 1];
        gameData.CurrentLevel = nextLevelId;
        gameData.TotalItems = data.CurrentLevelConfig.ItemCount;
        gameData.PlayerHealth = 3;  // 每关开始时重置玩家生命
        gameData.CollectedItems = 0;
        gameData.RemainingTime = data.CurrentLevelConfig.TimeLimit;

        //发送通知更新主界面
        SendNotification(NotificationConsts.ReFRESH_GAME_UI);
        GameModel.Instance.currentLevelData = ConfigMgr.Instance._allLevelDatas[nextLevelId - 1];
    }

}
