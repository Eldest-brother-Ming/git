
using System.Collections.Generic;
using Newtonsoft.Json;
using UnityEngine;

// LevelData类（JSON根结构的映射）
[System.Serializable]
public class LevelData
{
    public LevelConfig CurrentLevelConfig { get; set; }

    // 标记转换器：处理物品位置列表
    [JsonConverter(typeof(Vector2ListConverter))]
    public List<Vector2> ItemPositions { get; set; }
    public List<EnemyData> Enemies { get; set; }

    // 标记转换器：处理物品位置列表
    [JsonConverter(typeof(Vector2ListConverter))]
    public List<Vector2> ObstaclePositions { get; set; }
}