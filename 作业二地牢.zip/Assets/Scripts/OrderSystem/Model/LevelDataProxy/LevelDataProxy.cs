using System.Collections;
using System.Collections.Generic;
using PureMVC.Patterns;
using UnityEngine;

public class LevelDataProxy : Proxy
{
    public new const string NAME = "LevelDataProxy";

    public IList<LevelData> levels
    {
        get
        {
            return (IList<LevelData>)base.Data;
        }
    }

    public LevelDataProxy() : base(NAME, new List<LevelData>())
    {

    }

    public override void OnRegister()
    {
        base.OnRegister();
        //初始化所有关卡数据
        levels.Clear();
        for (int i = 0; i < ConfigMgr.Instance._allLevelDatas.Count; i++)
        {
            levels.Add(ConfigMgr.Instance._allLevelDatas[i]);
        }
    }

    public void AddLevelData(LevelData levelData)
    {
        levels.Add(levelData);
    }

    public void RemoveLevelData(LevelData levelData)
    {
        levels.Remove(levelData);
    }

}
