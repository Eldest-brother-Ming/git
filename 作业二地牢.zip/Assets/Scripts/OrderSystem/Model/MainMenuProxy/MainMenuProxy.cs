using System.Collections;
using System.Collections.Generic;
using PureMVC.Patterns;
using UnityEngine;

public class MainMenuProxy : Proxy
{
    public new const string NAME = "MainMenuProxy";

    public MainMenuProxy() : base(NAME, null)
    {
    }

    public override void OnRegister()
    {
        base.OnRegister();
    }
}
