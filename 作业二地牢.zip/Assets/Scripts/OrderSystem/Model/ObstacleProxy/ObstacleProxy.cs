using System.Collections;
using System.Collections.Generic;
using PureMVC.Patterns;
using UnityEngine;
public class ObstacleData
{
    public Vector2 ObstaclePosition;
    public GameObject ObstacleObj;
}
public class ObstacleProxy : Proxy
{
    public new const string NAME = "ObstacleProxy";

    public List<ObstacleData> ObstacleDatas
    {
        get
        {
            return (List<ObstacleData>)Data;
        }
    }
    public ObstacleProxy() : base(NAME, new List<ObstacleData>())
    {

    }

    public override void OnRegister()
    {
        //CreateItem();

    }

    //创建物品
    public void CreateItem()
    {
        ClearItemData();
        for (int i = 0; i < GameModel.Instance.currentLevelData.ObstaclePositions.Count; i++)
        {
            ObstacleDatas.Add(new ObstacleData
            {
                ObstaclePosition = GameModel.Instance.currentLevelData.ObstaclePositions[i],
                ObstacleObj = null
            });
        }
    }

    //销毁物品
    public void DestoryAllItem()
    {
        for (int i = 0; i < ObstacleDatas.Count; i++)
        {
            if (ObstacleDatas[i].ObstacleObj != null)
                GameObject.Destroy(ObstacleDatas[i].ObstacleObj);
        }
    }

    //添加物品信息
    public void AddItemData(ObstacleData itemData)
    {
        ObstacleDatas.Add(itemData);
    }
    public void RemoveItemData(ObstacleData itemData)
    {
        ObstacleDatas.Remove(itemData);
    }
    public void ClearItemData()
    {
        DestoryAllItem();
        ObstacleDatas.Clear();
    }
}

