using System.Collections;
using System.Collections.Generic;
using PureMVC.Patterns;
using UnityEngine;

public class PlayerDataProxy : Proxy
{
    public new const string NAME = "PlayerDataProxy";
    public Vector2 PlayerPosition { get; set; }
    public float MoveSpeed { get; set; }
    public bool HasPowerUp { get; set; }    //是否开启道具
    public PowerUpType ActivePowerUp { get; set; }  //道具效果
    public float PowerUpRemainingTime { get; set; }
    public GameObject playerObj { get; set; }
    public PlayerDataProxy() : base(NAME, null)
    {

    }

    /// <summary>
    /// 注册时初始化数据
    /// </summary>
    public override void OnRegister()
    {
        base.OnRegister();
        InitPlayerData();
    }

    public void InitPlayerData()
    {
        PlayerPosition = Vector2.zero;
        MoveSpeed = 3f;
        HasPowerUp = false;
        ActivePowerUp = PowerUpType.None;
        PowerUpRemainingTime = 5f;
    }
}
