using System;
using System.Collections;
using System.Collections.Generic;
using PureMVC.Patterns;
using UnityEngine;

public class SettingsProxy : Proxy
{
    public new const string NAME = "SettingsProxy";

    public float SoundVolume { get; set; }
    public float MusicVolume { get; set; }
    //public bool EnableEffects { get; set; }
    //public Resolution Resolution { get; set; }

    public SettingsProxy() : base(NAME, null)
    {
    }

    public override void OnRegister()
    {
        base.OnRegister();
        SoundVolume = PlayerPrefs.GetFloat("SoundVolume", 100f);
        MusicVolume = PlayerPrefs.GetFloat("MusicVolume", 100f);
    }

    internal void SetSoundVolume(float volume)
    {
        SoundVolume = volume;
        PlayerPrefs.SetFloat("SoundVolume", volume);
    }

    internal void SetMusicVolume(float volume)
    {
        MusicVolume = volume;
        PlayerPrefs.SetFloat("MusicVolume", volume);
    }
}
