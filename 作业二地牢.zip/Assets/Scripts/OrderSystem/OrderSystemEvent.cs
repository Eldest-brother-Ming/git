﻿
using Unity.Services.Apis.Economy;

public static class NotificationConsts
{
    // 游戏流程
    public const string STARTUP = "Startup";        // 启动
    public const string START_GAME = "StartGame";   // 开始游戏
    public const string LOAD_LEVEL = "LoadLevel";   // 加载关卡
    public const string LEVEL_STARTED = "LevelStarted"; // 关卡开始
    public const string LEVEL_COMPLETED = "LevelCompleted"; // 关卡完成
    public const string GAME_OVER = "GameOver"; // 游戏结束
    public const string RESTART_LEVEL = "RestartLevel"; // 重新开始关卡
    public const string GAME_EXIT = "GameExit"; // 退出游戏

    // 玩家相关
    public const string PLAYER_MOVE_INPUT = "PlayerMoveInput";  //，命令： 玩家移动输入
    public const string PLAYER_MOVE = "PlayerMove"; //通知： 玩家移动
    public const string PLAYER_DAMAGED = "PlayerDamaged";   // 玩家受伤
    public const string PLAYER_POWERUP = "PlayerPowerUp";   // 玩家获得道具

    // 游戏逻辑
    public const string ITEM_COLLECTED = "ItemCollected";   // 物品被收集
    public const string ENEMY_COLLISION = "EnemyCollision"; // 敌人发生碰撞
    public const string TIME_UPDATE = "TimeUpdate"; // 时间更新

    // UI更新
    public const string UPDATE_CURSELECTLEVEL = "UpdateCurSelectLevel";   // 通知：刷新当前选择关卡
    public const string UPDATE_SCORE = "UpdateScore";   // 通知：更新分数
    public const string UPDATE_HEALTH = "UpdateHealth"; // 通知：更新生命值
    public const string UPDATE_TIME = "UpdateTime"; // 通知：更新时间
    public const string UPDATE_ITEMS = "UpdateItems";   // 更新物品数量
    public const string ITEM_COLLECTED_UI = "ItemCollectedUI";  // 物品被收集
    public const string ReFRESH_GAME_UI = "RefreshGameUI"; // 刷新游戏UI

    // 游戏控制
    public const string CHANGE_GAMEDATA = "ChangeGamedata";    // 命令：更改游戏数据
    public const string PAUSE_GAME = "PauseGame";   // 暂停游戏（逻辑暂停）
    public const string GAME_PAUSED = "GamePaused"; // 游戏暂停（通知UI）
    public const string OPEN_SETTING_PANEL = "OpenSettingPanel";    //通知： 打开设置面板
    public const string GAME_RESUMED = "GameResumed";   // 游戏恢复
    public const string SAVE_GAME = "SaveGame"; // 保存游戏
    public const string LOAD_GAME = "LoadGame"; // 加载游戏


    // 设置
    public const string UPDATE_SETTINGS = "UpdateSettings"; // 更新设置
    public const string APPLY_SETTINGS = "ApplySettings";   // 应用设置

}

public class OrderCommandEvent
{

}
