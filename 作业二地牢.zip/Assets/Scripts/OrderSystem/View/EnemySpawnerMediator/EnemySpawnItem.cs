using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemySpawnItem : MonoBehaviour
{
    EnemyData enemyData;
    Vector2 startPosition, targetPosition;
    EnemySpawnerView enemySpawnerView;
    internal void Init(EnemyData enemyData, EnemySpawnerView enemySpawnerView)
    {
        this.enemySpawnerView = enemySpawnerView;
        this.enemyData = enemyData;
        this.startPosition = enemyData.PatrolPoints[0];
        this.targetPosition = enemyData.PatrolPoints[1];
    }

    // Update is called once per frame
    void Update()
    {
        if (enemyData == null) return;

        transform.position = Vector2.MoveTowards(transform.position, targetPosition, enemyData.Speed * Time.deltaTime);
        if (Vector2.Distance(transform.position, targetPosition) < 0.1f)
        {
            ChangeTargetPosition();
        }
    }

    private void ChangeTargetPosition()
    {
        Vector2 temp = startPosition;
        startPosition = targetPosition;
        targetPosition = temp;
    }

    void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.transform.tag == "Player")
        {
            enemySpawnerView.OnEnemyCollision?.Invoke();
        }
    }
}
