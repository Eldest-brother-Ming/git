using System;
using System.Collections;
using System.Collections.Generic;
using OrderSystem;
using PureMVC.Interfaces;
using PureMVC.Patterns;
using UnityEngine;

// 敌人生成器中介器
public class EnemySpawnerMediator : Mediator
{
    public new const string NAME = "EnemySpawnerMediator";

    private EnemySpawnerProxy enemySpawnerProxy;
    private EnemySpawnerView viewComponent
    {
        get { return (EnemySpawnerView)ViewComponent; }
    }
    public EnemySpawnerMediator(EnemySpawnerView view) : base(NAME, view)
    {
        
        viewComponent.OnEnemyCollision += () =>
        {
            SendNotification(NotificationConsts.ENEMY_COLLISION);
        };
    }

    public override void OnRegister()
    {
        base.OnRegister();
        enemySpawnerProxy = Facade.RetrieveProxy(EnemySpawnerProxy.NAME) as EnemySpawnerProxy;

    }

    public override IList<string> ListNotificationInterests()
    {
        List<string> list = new List<string>();
        list.Add(NotificationConsts.LEVEL_STARTED);
        list.Add(NotificationConsts.LEVEL_COMPLETED);
        list.Add(NotificationConsts.GAME_PAUSED);
        list.Add(NotificationConsts.GAME_RESUMED);
        //Debug.Log(list.Count);  
        return list;
    }

    public override void HandleNotification(INotification notification)
    {
        switch (notification.Name)
        {
            case NotificationConsts.LEVEL_STARTED:
                //Debug.Log("生成敌人");
                viewComponent.SpawnerEnemy(enemySpawnerProxy.Enemies);
                break;
            case NotificationConsts.LEVEL_COMPLETED:

                break;
            case NotificationConsts.GAME_PAUSED:

                break;
            case NotificationConsts.GAME_RESUMED:
                break;
        }
    }

}
