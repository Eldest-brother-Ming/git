using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;

public class EnemySpawnerView
{
    public UnityAction OnEnemyCollision;
    internal void SpawnerEnemy(List<EnemyData> enemies)
    {
        //Debug.Log(enemies.Count);
        for (int i = 0; i < enemies.Count; i++)
        {
            enemies[i].EnemyObject = GameObject.Instantiate(Resources.Load<GameObject>("Prefabs/Prefab/Enemy"));
            enemies[i].EnemyObject.transform.position = enemies[i].Position;
            enemies[i].EnemyObject.GetComponent<EnemySpawnItem>().Init(enemies[i],this);
        }
    }


}
