using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameUIItem : MonoBehaviour
{
    GameUIView gameUIView;
    internal void Init(GameUIView gameUIView)
    {
        this.gameUIView = gameUIView;
        InvokeRepeating("SubTimer",1,1);
    }

    private void SubTimer()
    {
        gameUIView.SubTiemr?.Invoke();
    }
}
