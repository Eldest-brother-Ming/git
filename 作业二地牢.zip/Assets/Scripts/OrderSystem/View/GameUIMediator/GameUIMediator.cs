using System;
using System.Collections;
using System.Collections.Generic;
using PureMVC.Interfaces;
using PureMVC.Patterns;
using UnityEngine;

public class GameUIMediator : Mediator
{
    public new const string NAME = "GameUIMediator";

    private GameDataProxy GameDataProxy;
    private GameUIView GameUIView
    {
        get
        {
            return (GameUIView)ViewComponent;
        }
    }

    public GameUIMediator(GameUIView view) : base(NAME, view)
    {
        GameUIView.OnPauseButtonClicked += () =>
        {
            SendNotification(NotificationConsts.PAUSE_GAME);
        };
        //游戏结束后点击返回选择关卡
        GameUIView.GameOver += () =>
        {
            SendNotification(NotificationConsts.LOAD_LEVEL, null, "ReturnSelectLevel");
        };
        GameUIView.SubTiemr += () =>
        {
            SendNotification(NotificationConsts.CHANGE_GAMEDATA,null,"SubTimer");
        };
    }

    public override void OnRegister()
    {
        base.OnRegister();
        //获取游戏数据的代理
        GameDataProxy = Facade.RetrieveProxy(GameDataProxy.NAME) as GameDataProxy;
        GameUIView.Init();
        GameUIView.RefreshGameUI(GameDataProxy.gameData);
    }

    // 注册需要侦听的事件名
    public override IList<string> ListNotificationInterests()
    {
        return new List<string>
        {
            NotificationConsts.ReFRESH_GAME_UI,
            NotificationConsts.UPDATE_SCORE,
            NotificationConsts.UPDATE_TIME,
            NotificationConsts.UPDATE_HEALTH,
            NotificationConsts.GAME_PAUSED,
            NotificationConsts.GAME_RESUMED,
            NotificationConsts.GAME_OVER,
            NotificationConsts.GAME_EXIT,
            NotificationConsts.LEVEL_STARTED
        };
    }

    // 根据事件名处理事件
    public override void HandleNotification(INotification notification)
    {
        switch (notification.Name)
        {
            case NotificationConsts.ReFRESH_GAME_UI:
                GameUIView.RefreshGameUI(GameDataProxy.gameData);
                break;
            case NotificationConsts.UPDATE_SCORE:
                UpdateScoreUI((int)notification.Body);
                break;
            case NotificationConsts.UPDATE_TIME:
                UpdateTimeUI((float)notification.Body);
                break;
            case NotificationConsts.UPDATE_HEALTH:
                UpdateHealthUI((int)notification.Body);
                break;
            case NotificationConsts.GAME_PAUSED:
                ShowPauseMenu();
                break;
            case NotificationConsts.GAME_RESUMED:
                ShowPauseMenu();
                break;
            case NotificationConsts.GAME_OVER:
                ShowGameOverUI((bool)notification.Body); // true=胜利, false=失败
                break;
            case NotificationConsts.GAME_EXIT:
                GameUIView.DestoryPanel();
                break;
            case NotificationConsts.LEVEL_STARTED:
                GameUIView.ShowPanel();
                break;
        }
    }

    /// <summary>
    /// 显示游戏结束UI
    /// </summary>
    /// <param name="body"></param>
    /// <exception cref="NotImplementedException"></exception>
    private void ShowGameOverUI(bool body)
    {
        GameUIView.ShowGameOverPanel(body);
    }

    /// <summary>
    /// 显示暂停菜单
    /// </summary>
    /// <exception cref="NotImplementedException"></exception>
    private void ShowPauseMenu()
    {
        GameUIView.RefreshGameUI(GameDataProxy.gameData);
    }

    /// <summary>
    /// 刷新玩家生命UI
    /// </summary>
    /// <param name="body"></param>
    /// <exception cref="NotImplementedException"></exception>    
    private void UpdateHealthUI(int body)
    {

    }

    /// <summary>
    /// 更新时间UI
    /// </summary>
    /// <param name="body"></param>
    /// <exception cref="NotImplementedException"></exception>
    private void UpdateTimeUI(float body)
    {
        GameUIView.Timer.text = body.ToString("F0");
    }

    /// <summary>
    /// 更新分数UI
    /// </summary>
    /// <param name="body"></param>
    /// <exception cref="NotImplementedException"></exception>
    private void UpdateScoreUI(int body)
    {
        GameUIView.RefreshGameUI(GameDataProxy.gameData);
    }
}
