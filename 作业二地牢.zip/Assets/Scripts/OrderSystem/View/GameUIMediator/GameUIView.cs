using System;
using System.Collections;
using System.Collections.Generic;
using System.Threading;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class GameUIView
{
    public UnityAction OnPauseButtonClicked, GameOver,SubTiemr;
    GameObject MainUI, GameOverPanel;
    public Text Timer, Score, Healthy, BtnInfo, Collected, endInfo;
    Button PauseBtn, returnBtn;

    internal void DestoryPanel()
    {
        MainUI.SetActive(false);
    }

    internal void Init()
    {
        MainUI = GameObject.Instantiate(Resources.Load<GameObject>("Prefabs/UI/MainUI"), GameObject.Find("Canvas").transform);
        MainUI.GetComponent<GameUIItem>().Init(this);
        Timer = MainUI.transform.Find("Timer").GetComponent<Text>();
        Score = MainUI.transform.Find("Score").GetComponent<Text>();
        Healthy = MainUI.transform.Find("Healthy").GetComponent<Text>();
        BtnInfo = MainUI.transform.Find("PauseBtn/info").GetComponent<Text>();
        Collected = MainUI.transform.Find("Collected").GetComponent<Text>();

        GameOverPanel = MainUI.transform.Find("GameOverPanel").gameObject;
        returnBtn = GameOverPanel.transform.Find("returnBtn").GetComponent<Button>();
        returnBtn.onClick.AddListener(() =>
        {
            GameOver?.Invoke();
            GameOverPanel.SetActive(false);
        });
        endInfo = GameOverPanel.transform.Find("EndInfo").GetComponent<Text>();
        GameOverPanel.SetActive(false);


        PauseBtn = MainUI.transform.Find("PauseBtn").GetComponent<Button>();
        PauseBtn.onClick.AddListener(() =>
        {
            //暂停
            OnPauseButtonClicked?.Invoke();
        });

    }

    internal void RefreshGameUI(GameData gameData)
    {
        Timer.text = gameData.RemainingTime.ToString("F0");
        Score.text = gameData.CurrentScore.ToString();
        Healthy.text = gameData.PlayerHealth.ToString();
        Collected.text = gameData.CollectedItems.ToString();
        if (gameData.GameState == GameState.Playing)
        {
            BtnInfo.text = "继续";
        }
        else if (gameData.GameState == GameState.Paused)
        {
            BtnInfo.text = "暂停";
        }
    }

    internal void ShowPanel()
    {
        MainUI.SetActive(true);
    }
    
    internal void ShowGameOverPanel(bool isWin)
    {
        if (isWin)
        {
            endInfo.text = "通关!!!";
        }
        else
        {
            endInfo.text = "菜!!!";
        }
        Time.timeScale = 0;
        // endInfo.text = isWin ? "通关!!！" : "很遗憾，失败了！";
        GameOverPanel.SetActive(true);
    }
}
