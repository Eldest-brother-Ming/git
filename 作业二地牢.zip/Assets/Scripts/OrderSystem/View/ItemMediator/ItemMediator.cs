using System.Collections;
using System.Collections.Generic;
using PureMVC.Interfaces;
using PureMVC.Patterns;
using UnityEngine;
// 物品中介器
public class ItemMediator : Mediator
{
    public new const string NAME = "ItemMediator";

    private ItemProxy itemProxy;

    private ItemView viewComponent
    {
        get { return (ItemView)ViewComponent; }
    }

    public ItemMediator(ItemView view) : base(NAME, view)
    {
        viewComponent.OnItemCollected += (GameObject item) =>
        {
            SendNotification(NotificationConsts.ITEM_COLLECTED, item);
        };

    }

    public override void OnRegister()
    {
        itemProxy = Facade.RetrieveProxy(ItemProxy.NAME) as ItemProxy;

    }

    public override IList<string> ListNotificationInterests()
    {
        return  new List<string>
        {
            NotificationConsts.LEVEL_STARTED,
            NotificationConsts.LEVEL_COMPLETED,
            NotificationConsts.GAME_PAUSED,
            NotificationConsts.GAME_RESUMED
        };
    }

    public override void HandleNotification(INotification notification)
    {
        switch (notification.Name)
        {
            case NotificationConsts.LEVEL_STARTED:
                // 关卡开始时创建物品
                viewComponent.CreateItems(itemProxy.ItemDatas);
                break;
            case NotificationConsts.LEVEL_COMPLETED:
                // 关卡完成时发命令销毁物品
               
                break;
            case NotificationConsts.GAME_PAUSED:

                break;
            case NotificationConsts.GAME_RESUMED:

                break;
        }
    }
}
