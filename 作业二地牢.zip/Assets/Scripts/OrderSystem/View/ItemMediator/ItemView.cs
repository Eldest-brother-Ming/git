using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;

public class ItemView
{
    public UnityAction<GameObject> OnItemCollected;

    internal void CreateItems(List<ItemData> itemDatas)
    {
        for (int i = 0; i < itemDatas.Count; i++)
        {
            Item item = GameObject.Instantiate(Resources.Load<Item>("Prefabs/Prefab/Collect"), itemDatas[i].itemPosition, Quaternion.identity);
            itemDatas[i].itemObj = item.gameObject;
            item.Init(this);
        }
    }
}
