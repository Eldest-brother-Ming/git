using System;
using System.Collections;
using System.Collections.Generic;
using PureMVC.Interfaces;
using PureMVC.Patterns;
using UnityEngine;

public class MainMenuMediator : Mediator
{
    public new const string NAME = "MainMenuMediator";

    // 关卡数据代理
    private LevelDataProxy levelDataProxy = null;

    public MainMenuView MainMenuView
    {
        get
        {
            return (MainMenuView)ViewComponent;
        }
    }

    public MainMenuMediator(MainMenuView view) : base(NAME, view)
    {
        // 进入游戏按钮点击事件
        MainMenuView.EnterGame += () =>
        {
            //改变游戏状态为Playing并跳转场景
            SendNotification(NotificationConsts.CHANGE_GAMEDATA, GameState.Playing, "GameState");
            //初始化Playing场景中的模块
            //SendNotification(NotificationConsts.STARTUP,null,"Playing");
        };
        MainMenuView.OpenSettingPanel += () => { SendNotification(NotificationConsts.OPEN_SETTING_PANEL); };
        MainMenuView.SelectLevel += (LevelData levelData) =>
        {
            SendNotification(NotificationConsts.CHANGE_GAMEDATA, levelData, "Level");
        };

        MainMenuView.Init();
    }
    
    public override void OnRegister()
    {
        base.OnRegister();
        levelDataProxy = Facade.RetrieveProxy(LevelDataProxy.NAME) as LevelDataProxy;
        if (levelDataProxy == null)
        {
            throw new Exception(LevelDataProxy.NAME + "是空!");
        }
        ;
        MainMenuView.UpdateMainMenuItem(levelDataProxy.levels);
    }


    public override IList<string> ListNotificationInterests()
    {
        return new List<string>
        {
            NotificationConsts.UPDATE_CURSELECTLEVEL,
            NotificationConsts.GAME_EXIT
        };
    }


    public override void HandleNotification(INotification notification)
    {
        switch (notification.Name)
        {
            case NotificationConsts.UPDATE_CURSELECTLEVEL:
                MainMenuView.UpdateCurrentSelectLevel((int)notification.Body);
                break;
            case NotificationConsts.GAME_EXIT:
                MainMenuView.ShowPanel();
                break;
        }
    }
}
