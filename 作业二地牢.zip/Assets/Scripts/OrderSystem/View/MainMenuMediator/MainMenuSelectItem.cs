using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class MainMenuSelectItem : MonoBehaviour
{
    LevelData mydata;
    MainMenuView mainMenuView;
    public Button selfBtn;
    public Text Name,CollectCount,EnemyCount,LimitTime;

    internal void RefreshPanel(LevelData levelData, MainMenuView mainMenuView)
    {
        mydata = levelData;
        this.mainMenuView = mainMenuView;

        Name.text = levelData.CurrentLevelConfig.LevelName;
        CollectCount.text = levelData.CurrentLevelConfig.ItemCount + "个";
        EnemyCount.text = levelData.Enemies.Count + "个";
        LimitTime.text = levelData.CurrentLevelConfig.TimeLimit + "秒";

        selfBtn.onClick.RemoveAllListeners();
        selfBtn.onClick.AddListener(() =>
        {
            mainMenuView.SelectLevel?.Invoke(levelData);
        });
    }

}
