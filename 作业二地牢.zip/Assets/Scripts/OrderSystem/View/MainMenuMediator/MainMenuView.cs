using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

public class MainMenuView
{
    public UnityAction OpenSettingPanel, EnterGame;
    public UnityAction<LevelData> SelectLevel;
    private Button enterGameBtn, settingBtn;
    private Text curSceletLevel;
    private GameObject Canvas, SelectLevelPanel;
    private Transform content;
    public void Init()
    {
        Canvas = GameObject.Find("Canvas");
        SelectLevelPanel = Canvas.transform.Find("SelectLevelPanel").gameObject;


        settingBtn = GameObject.Find("Canvas/SelectLevelPanel/SettingBtn").GetComponent<Button>();
        enterGameBtn = GameObject.Find("Canvas/SelectLevelPanel/GameStartBtn").GetComponent<Button>();
        curSceletLevel = GameObject.Find("Canvas/SelectLevelPanel/Window/CurSelect").GetComponent<Text>();
        UpdateCurrentSelectLevel(1);
        content = GameObject.Find("Canvas/SelectLevelPanel/Window/Scroll View/Viewport/Content").GetComponent<Transform>();

        enterGameBtn.onClick.AddListener(() =>
        {
            EnterGame?.Invoke();
            SelectLevelPanel.SetActive(false);
        });
        settingBtn.onClick.AddListener(() => { OpenSettingPanel?.Invoke(); });
    }

    public void ShowPanel()
    {
        SelectLevelPanel.SetActive(true);
    }

    /// <summary>
    /// 修改当前选中的关卡显示
    /// </summary>
    /// <param name="body"></param>
    internal void UpdateCurrentSelectLevel(int body)
    {
        curSceletLevel.text = body.ToString();
    }

    /// <summary>
    /// 更新关卡列表
    /// </summary>
    /// <param name="levels"></param>
    internal void UpdateMainMenuItem(IList<LevelData> levels)
    {
        for (int i = 0; i < levels.Count; i++)
        {
            GameObject levelItem = GameObject.Instantiate(Resources.Load<GameObject>("Prefabs/UI/LevelItem"), content);
            levelItem.name = "LevelItem" + i;
            levelItem.GetComponent<MainMenuSelectItem>().RefreshPanel(levels[i], this);
        }
    }
}
