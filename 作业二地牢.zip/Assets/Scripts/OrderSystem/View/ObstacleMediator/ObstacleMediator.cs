using System.Collections;
using System.Collections.Generic;
using PureMVC.Interfaces;
using PureMVC.Patterns;
using UnityEngine;

public class ObstacleMediator : Mediator
{
    public new const string NAME = "ObstacleMediator";

    private ObstacleProxy obstacleProxy;
    private ObstacleView view
    {
        get { return (ObstacleView)ViewComponent; }
    }
    public ObstacleMediator(ObstacleView view) : base(NAME, view)
    {

    }

    public override void OnRegister()
    {
        obstacleProxy = Facade.RetrieveProxy(ObstacleProxy.NAME) as ObstacleProxy;
    }


    public override IList<string> ListNotificationInterests()
    {
        return new List<string>
        {
            NotificationConsts.LEVEL_STARTED,
            NotificationConsts.LEVEL_COMPLETED,
            NotificationConsts.GAME_PAUSED,
            NotificationConsts.GAME_RESUMED
        };
    }

    public override void HandleNotification(INotification notification)
    {
        switch (notification.Name)
        {
            case NotificationConsts.LEVEL_STARTED:
                CreateObstacles();
                break;
            case NotificationConsts.LEVEL_COMPLETED:
                // 关卡完成时发命令销毁物品
                obstacleProxy.ClearItemData();
                break;
            case NotificationConsts.GAME_PAUSED:

                break;
            case NotificationConsts.GAME_RESUMED:

                break;
        }
    }

    /// <summary>
    /// 创建障碍物
    /// </summary>
    private void CreateObstacles()
    {
        for (int i = 0; i < obstacleProxy.ObstacleDatas.Count; i++)
        {
            GameObject obstaclePrefab = Resources.Load<GameObject>("Prefabs/Prefab/Obstacle");
            obstacleProxy.ObstacleDatas[i].ObstacleObj = GameObject.Instantiate(obstaclePrefab, obstacleProxy.ObstacleDatas[i].ObstaclePosition, Quaternion.identity);
        }

    }
}
