using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerItem : MonoBehaviour
{
    private static PlayerItem instance;
    public static PlayerItem Instance { get => instance; set => instance = value; }

    PlayerView playerview;
    PlayerDataProxy playerDataProxy;
    float h, v;

    void Awake()
    {
        instance = this;
    }

    void Update()
    {
        //玩家移动
        h = Input.GetAxis("Horizontal");
        v = Input.GetAxis("Vertical");
        if (h != 0 || v != 0)
        {
            //发送通知变换玩家位置
            playerview.playerMove?.Invoke(new Vector2(h, v));
        }
    }

    internal void Init(PlayerDataProxy playerDataProxy, PlayerView playerView)
    {
        this.playerview = playerView;
        this.playerDataProxy = playerDataProxy;
    }
}
