using System.Collections;
using System.Collections.Generic;
using PureMVC.Interfaces;
using PureMVC.Patterns;
using UnityEngine;

public class PlayerMediator : Mediator
{
    public new const string NAME = "PlayerMediator";

    private PlayerDataProxy PlayerDataProxy;

    private PlayerView playerView
    {
        get
        {
            return (PlayerView)ViewComponent;
        }
    }

    public PlayerMediator(PlayerView view) : base(NAME, view)
    {
        playerView.playerMove += (Vector2 body) =>
        {
            SendNotification(NotificationConsts.PLAYER_MOVE_INPUT, body);
        };

    }

    public override void OnRegister()
    {
        PlayerDataProxy = Facade.RetrieveProxy(PlayerDataProxy.NAME) as PlayerDataProxy;
        //playerView.Init(PlayerDataProxy);
    }



    public override IList<string> ListNotificationInterests()
    {
        return new List<string>
        {
            NotificationConsts.LEVEL_STARTED,
            NotificationConsts.PLAYER_MOVE,
            NotificationConsts.PLAYER_DAMAGED,
            NotificationConsts.PLAYER_POWERUP,
            NotificationConsts.GAME_EXIT
        };
    }

    public override void HandleNotification(INotification notification)
    {
        switch (notification.Name)
        {
            case NotificationConsts.LEVEL_STARTED:
                playerView.Init(PlayerDataProxy);
                break;
            case NotificationConsts.PLAYER_MOVE:
                playerView.Move((Vector2)notification.Body);
                break;
            case NotificationConsts.PLAYER_DAMAGED:
                playerView.TakeDamage((int)notification.Body);
                break;
            case NotificationConsts.PLAYER_POWERUP:
                playerView.ActivatePowerUp((PowerUpData)notification.Body);
                break;
            case NotificationConsts.GAME_EXIT:
                PlayerDataProxy.playerObj = null;
                break;
        }
    }
}
