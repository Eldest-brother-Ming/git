using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;

public class PlayerView
{
    PlayerDataProxy playerDataProxy;

    public UnityAction<Vector2> playerMove;

    internal void Init(PlayerDataProxy playerDataProxy)
    {
        this.playerDataProxy = playerDataProxy;
        if (playerDataProxy.playerObj == null)
        {
            playerDataProxy.playerObj = GameObject.Instantiate(Resources.Load<GameObject>("Prefabs/Prefab/Player"));
            playerDataProxy.playerObj.GetComponent<PlayerItem>().Init(playerDataProxy, this);
        }
    }

    /// <summary>
    /// 激活道具
    /// </summary>
    /// <param name="body"></param>
    /// <exception cref="NotImplementedException"></exception>
    internal void ActivatePowerUp(PowerUpData body)
    {

    }

    /// <summary>
    /// 移动
    /// </summary>
    /// <param name="body"></param>
    /// <exception cref="NotImplementedException"></exception>
    internal void Move(Vector2 body)
    {
        playerDataProxy.playerObj.transform.position = new Vector3(body.x, body.y, 0);
    }

    /// <summary>
    /// 扣血
    /// </summary>
    /// <param name="body"></param>
    /// <exception cref="NotImplementedException"></exception>
    internal void TakeDamage(int body)
    {

    }

}
