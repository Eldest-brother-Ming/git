using System.Collections;
using System.Collections.Generic;
using PureMVC.Interfaces;
using PureMVC.Patterns;
using UnityEngine;

public class SettingMediator : Mediator
{
    public new const string NAME = "SettingMediator";

    private SettingView settingView
    {
        get
        {
            return (SettingView)ViewComponent;
        }
    }

    public SettingMediator(SettingView view) : base(NAME, view)
    {
        //注册View的消息和初始化View
        settingView.UpdateSoundVolume += (float value) =>
        {
            SendNotification(NotificationConsts.UPDATE_SETTINGS,value,"Sound");
        };
        settingView.UpdateMusicVolume += (float value) =>
        {
            SendNotification(NotificationConsts.UPDATE_SETTINGS,value,"Music");
        };
        settingView.returnSelectLevelPanel += () =>
        {
            SendNotification(NotificationConsts.LOAD_LEVEL,null,"ReturnSelectLevel");
        };

    }


    public override void OnRegister()
    {
        base.OnRegister();
        //刷新ViewPanel
        settingView.Init();
    }

    /// <summary>
    /// 侦听的消息
    /// </summary>
    /// <returns></returns>
    public override IList<string> ListNotificationInterests()
    {
        return new List<string>
        {
            NotificationConsts.OPEN_SETTING_PANEL
        };
    }

    /// <summary>
    /// 响应消息
    /// </summary>
    public override void HandleNotification(INotification notification)
    {
        switch (notification.Name)
        {
            case NotificationConsts.OPEN_SETTING_PANEL:
                settingView.ClosePanel(true);
                break;
        }
    }
}
