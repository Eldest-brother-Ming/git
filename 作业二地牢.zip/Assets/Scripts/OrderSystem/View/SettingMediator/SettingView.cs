using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class SettingView
{
    private GameObject SettingPanel;
    public Button closeBtn, exitBtn;
    public Slider soundVolume, MusicVolume;
    public UnityAction<float> UpdateSoundVolume, UpdateMusicVolume;
    public UnityAction returnSelectLevelPanel;
    internal void Init()
    {
        SettingPanel = GameObject.Instantiate(Resources.Load<GameObject>("Prefabs/UI/SettingPanel"), GameObject.Find("Canvas").transform);
        closeBtn = SettingPanel.transform.Find("CloseBtn").GetComponent<Button>();
        exitBtn = SettingPanel.transform.Find("ExitBtn").GetComponent<Button>();
        soundVolume = SettingPanel.transform.Find("Sound/SoundVolume").GetComponent<Slider>();
        MusicVolume = SettingPanel.transform.Find("Music/MusicVolume").GetComponent<Slider>();

        closeBtn.onClick.AddListener(() =>
        {
            ClosePanel(false);
        });
        exitBtn.onClick.AddListener(() =>
        {
            if (SceneManager.GetActiveScene().name == "MainMenu")
            {
                ClosePanel(false);
                return;
            }
            returnSelectLevelPanel?.Invoke();
            ClosePanel(false);
        });

        soundVolume.onValueChanged.AddListener((value) =>
        {
            UpdateSoundVolume?.Invoke(value);
        });
        MusicVolume.onValueChanged.AddListener((value) =>
        {
            UpdateMusicVolume?.Invoke(value);
        });

        soundVolume.value = PlayerPrefs.GetFloat("SoundVolume", 100f);
        MusicVolume.value = PlayerPrefs.GetFloat("MusicVolume", 100f);

        ClosePanel(false);
    }



    public void ClosePanel(bool isOpen)
    {
        SettingPanel.SetActive(isOpen);
    }

}
