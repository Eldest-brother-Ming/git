using System.Collections;
using System.Collections.Generic;
using JsonFx.Json;
using Newtonsoft.Json;
using UnityEngine;

public class ConfigMgr : Singleton<ConfigMgr>
{
    public List<LevelData> _allLevelDatas = new List<LevelData>();

    public void LoadLevelConfig()
    {
        // 加载JSON文件（路径：Resources/Configs/LevelConfig.json）
        TextAsset jsonAsset = Resources.Load<TextAsset>("Json/LevelConfig");
        if (jsonAsset == null)
        {
            Debug.LogError("LevelConfig.json 加载失败！检查Resources/Configs路径");
            return;
        }

        try
        {
            // 反序列化时自动应用自定义转换器
            _allLevelDatas = JsonConvert.DeserializeObject<List<LevelData>>(jsonAsset.text);
            // Debug.Log($"成功加载 {_allLevelDatas.Count} 个关卡配置");
        }
        catch (System.Exception e)
        {
            // Debug.LogError($"解析失败：{e.Message}\n{e.StackTrace}");
        }
    }

    // 根据ID获取关卡数据
    public LevelData GetLevelDataById(int levelId)
    {
        if (_allLevelDatas == null)
        {
            // Debug.LogWarning("关卡配置未加载！");
            return null;
        }
        return _allLevelDatas.Find(data => data.CurrentLevelConfig.LevelId == levelId);
    }

    // 获取所有关卡数据
    public List<LevelData> GetAllLevelDatas() => _allLevelDatas ?? new List<LevelData>();
}
