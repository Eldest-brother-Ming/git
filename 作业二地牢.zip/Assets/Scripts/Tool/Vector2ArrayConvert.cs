using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// 适配JSON数组包裹Vector2对象的自定义转换器
/// 处理格式：[{"X":x,"Y":y}] → Vector2(x,y)
/// </summary>
public class Vector2ArrayConverter : JsonConverter<Vector2>
{
    // 反序列化（核心逻辑）
    public override Vector2 ReadJson(JsonReader reader, Type objectType, Vector2 existingValue, bool hasExistingValue, JsonSerializer serializer)
    {
        // 情况1：JSON是数组（如 [{"X":10,"Y":10}]）
        if (reader.TokenType == JsonToken.StartArray)
        {
            reader.Read(); // 跳过数组开始符 [
            // 读取数组内的Vector2对象
            float x = 0, y = 0;
            if (reader.TokenType == JsonToken.StartObject)
            {
                while (reader.Read() && reader.TokenType != JsonToken.EndObject)
                {
                    string propertyName = reader.Value.ToString();
                    reader.Read();
                    if (propertyName.Equals("X", StringComparison.OrdinalIgnoreCase))
                        x = Convert.ToSingle(reader.Value);
                    else if (propertyName.Equals("Y", StringComparison.OrdinalIgnoreCase))
                        y = Convert.ToSingle(reader.Value);
                }
            }
            reader.Read(); // 跳过数组结束符 ]
            return new Vector2(x, y);
        }

        // 情况2：JSON是纯对象（如 {"X":10,"Y":10}）
        if (reader.TokenType == JsonToken.StartObject)
        {
            float x = 0, y = 0;
            while (reader.Read() && reader.TokenType != JsonToken.EndObject)
            {
                string propertyName = reader.Value.ToString();
                reader.Read();
                if (propertyName.Equals("X", StringComparison.OrdinalIgnoreCase))
                    x = Convert.ToSingle(reader.Value);
                else if (propertyName.Equals("Y", StringComparison.OrdinalIgnoreCase))
                    y = Convert.ToSingle(reader.Value);
            }
            return new Vector2(x, y);
        }

        // 兜底返回默认值
        return Vector2.zero;
    }

    // 序列化（可选，如需将Vector2转回JSON数组格式则实现）
    public override void WriteJson(JsonWriter writer, Vector2 value, JsonSerializer serializer)
    {
        writer.WriteStartArray();
        writer.WriteStartObject();
        writer.WritePropertyName("X");
        writer.WriteValue(value.x);
        writer.WritePropertyName("Y");
        writer.WriteValue(value.y);
        writer.WriteEndObject();
        writer.WriteEndArray();
    }
}

/// <summary>
/// 适配List<Vector2>的转换器（处理ItemPositions/ObstaclePositions等纯对象列表）
/// 处理格式：[{"X":x,"Y":y}, {"X":x2,"Y":y2}] → List<Vector2>
/// </summary>
public class Vector2ListConverter : JsonConverter<List<Vector2>>
{
    public override List<Vector2> ReadJson(JsonReader reader, Type objectType, List<Vector2> existingValue, bool hasExistingValue, JsonSerializer serializer)
    {
        List<Vector2> vectorList = new List<Vector2>();
        if (reader.TokenType == JsonToken.StartArray)
        {
            while (reader.Read() && reader.TokenType != JsonToken.EndArray)
            {
                if (reader.TokenType == JsonToken.StartObject)
                {
                    float x = 0, y = 0;
                    while (reader.Read() && reader.TokenType != JsonToken.EndObject)
                    {
                        string propName = reader.Value.ToString();
                        reader.Read();
                        if (propName.Equals("X", StringComparison.OrdinalIgnoreCase))
                            x = Convert.ToSingle(reader.Value);
                        else if (propName.Equals("Y", StringComparison.OrdinalIgnoreCase))
                            y = Convert.ToSingle(reader.Value);
                    }
                    vectorList.Add(new Vector2(x, y));
                }
            }
        }
        return vectorList;
    }

    public override void WriteJson(JsonWriter writer, List<Vector2> value, JsonSerializer serializer)
    {
        writer.WriteStartArray();
        foreach (var vec in value)
        {
            writer.WriteStartObject();
            writer.WritePropertyName("X");
            writer.WriteValue(vec.x);
            writer.WritePropertyName("Y");
            writer.WriteValue(vec.y);
            writer.WriteEndObject();
        }
        writer.WriteEndArray();
    }
}